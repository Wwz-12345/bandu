/* ============================================================
   Book content — 《小蜗牛找月亮》/ "Little Snail Looks for the Moon"
   Original story. 8 pages. Every page carries both阅读 layers:
     A: sentences (read-along, one utterance per sentence)
     B: fact card + word glossary + optional quiz + scene hotspots
   ============================================================ */
const BOOK = {
  id: "snail-moon",
  title: { zh: "小蜗牛找月亮", en: "Little Snail Looks for the Moon" },
  pages: [
    /* ---------------- 1 ---------------- */
    {
      scene: "p1",
      zh: ["夜里，花园安静下来。", "小蜗牛慢慢爬上一片叶子。"],
      en: ["Night came, and the garden grew quiet.", "Little Snail climbed slowly onto a leaf."],
      fact: {
        zh: { title: "两对触角", body: "小蜗牛头上有两对触角：长的那对顶上长着眼睛，短的那对用来闻味道。" },
        en: { title: "Two pairs of feelers", body: "A snail has two pairs of feelers. The long pair carries eyes at the tips; the short pair is for smelling." },
      },
      words: [
        { zh: "触角", en: "feelers", def: { zh: "头上软软的、会动的小棍，用来感觉周围。", en: "Soft moving stalks on the head, used to feel the world." } },
      ],
      quiz: {
        zh: { prompt: "小蜗牛用什么看路？", options: [{ icon: "feeler", correct: true, label: "触角" }, { icon: "eye", label: "眼睛" }, { icon: "foot", label: "脚" }] },
        en: { prompt: "What does Little Snail use to find his way?", options: [{ icon: "feeler", correct: true, label: "Feelers" }, { icon: "eye", label: "Eyes" }, { icon: "foot", label: "Feet" }] },
      },
      spots: [
        { x: 0.75, y: 0.2, zh: "月亮", en: "the moon" },
        { x: 0.33, y: 0.76, zh: "小蜗牛", en: "Little Snail" },
      ],
      sticker: "🌱",
    },
    /* ---------------- 2 ---------------- */
    {
      scene: "p2",
      zh: ["月亮挂得那么高。", "小蜗牛伸长触角，也够不到。"],
      en: ["The moon hung so high.", "Little Snail stretched his feelers, but he could not reach it."],
      fact: {
        zh: { title: "月亮不会自己发光", body: "月亮看起来亮亮的，其实是把太阳的光反射给了我们。" },
        en: { title: "The moon makes no light of its own", body: "It only looks bright because it reflects sunlight back to us." },
      },
      words: [
        { zh: "够不着", en: "out of reach", def: { zh: "太远或太高，手伸过去也拿不到。", en: "Too far or too high to touch." } },
      ],
      quiz: {
        zh: { prompt: "月亮的光是从哪里来的？", options: [{ icon: "sun", correct: true, label: "太阳" }, { icon: "moon", label: "月亮自己" }, { icon: "star", label: "星星" }] },
        en: { prompt: "Where does the moon's light come from?", options: [{ icon: "sun", correct: true, label: "The sun" }, { icon: "moon", label: "The moon itself" }, { icon: "star", label: "The stars" }] },
      },
      spots: [
        { x: 0.5, y: 0.28, zh: "月亮", en: "the moon" },
        { x: 0.5, y: 0.8, zh: "触角", en: "feelers" },
      ],
      sticker: "🌙",
    },
    /* ---------------- 3 ---------------- */
    {
      scene: "p3",
      zh: ["“瓢虫姐姐，你能带我去月亮那儿吗？”", "“太远啦，”瓢虫说，“我飞到天亮也到不了。”"],
      en: ["“Ladybird, could you take me to the moon?”", "“Far too far,” said Ladybird. “I could fly till morning and never get there.”"],
      fact: {
        zh: { title: "壳下的飞翅", body: "瓢虫硬硬的外壳下面，藏着一对薄薄的飞翅，只有飞的时候才张开。" },
        en: { title: "Wings under the shell", body: "Under a ladybird's hard shell hides a pair of thin flying wings, opened only in flight." },
      },
      words: [
        { zh: "瓢虫", en: "ladybird", def: { zh: "圆圆的小甲虫，背上有红色或黄色的壳。", en: "A little round beetle with red or yellow wing cases." } },
      ],
      quiz: {
        zh: { prompt: "瓢虫靠什么飞起来？", options: [{ icon: "wing", correct: true, label: "壳下的飞翅" }, { icon: "feeler", label: "触角" }, { icon: "foot", label: "脚" }] },
        en: { prompt: "What does Ladybird use to fly?", options: [{ icon: "wing", correct: true, label: "Hidden wings" }, { icon: "feeler", label: "Feelers" }, { icon: "foot", label: "Feet" }] },
      },
      spots: [
        { x: 0.715, y: 0.6, zh: "瓢虫", en: "ladybird" },
        { x: 0.155, y: 0.252, zh: "月亮", en: "the moon" },
      ],
      sticker: "🐞",
    },
    /* ---------------- 4 ---------------- */
    {
      scene: "p4",
      zh: ["池塘边的青蛙笑了：“月亮就在水里呀，你看！”", "水面亮亮的，真的有一个月亮。"],
      en: ["By the pond, Frog laughed. “The moon is right there in the water — look!”", "The water shimmered, and there really was a moon in it."],
      fact: {
        zh: { title: "水里的月亮是倒影", body: "水面像一面镜子，把月光反射回来。真的月亮一直都在天上。" },
        en: { title: "The moon in the water is a reflection", body: "Water works like a mirror and bounces the moonlight back. The real moon never left the sky." },
      },
      words: [
        { zh: "倒影", en: "reflection", def: { zh: "东西照在水面或镜子里，出现的那个“影子”。", en: "The copy of something seen in water or a mirror." } },
      ],
      quiz: {
        zh: { prompt: "池塘里的月亮是什么？", options: [{ icon: "water", correct: true, label: "倒影" }, { icon: "moon", label: "真的月亮" }, { icon: "stone", label: "一块石头" }] },
        en: { prompt: "What is the moon in the pond?", options: [{ icon: "water", correct: true, label: "A reflection" }, { icon: "moon", label: "The real moon" }, { icon: "stone", label: "A stone" }] },
      },
      spots: [
        { x: 0.7, y: 0.62, zh: "青蛙", en: "frog" },
        { x: 0.75, y: 0.82, zh: "水里的月亮", en: "the moon in the water" },
      ],
      sticker: "🐸",
    },
    /* ---------------- 5 ---------------- */
    {
      scene: "p5",
      zh: ["一阵风吹过，水面碎了。", "月亮散成一片一片，不见了。"],
      en: ["A breeze swept over the water and broke it into ripples.", "The moon scattered into pieces and was gone."],
      fact: {
        zh: { title: "涟漪", body: "风把水面吹出一圈一圈的波纹，叫做涟漪。它们会一圈推着一圈，慢慢散开。" },
        en: { title: "Ripples", body: "Wind pushes the water into rings called ripples. Each ring pushes the next, spreading out slowly." },
      },
      words: [
        { zh: "涟漪", en: "ripple", def: { zh: "水面上一圈一圈荡开的波纹。", en: "A ring of small waves spreading over water." } },
      ],
      quiz: {
        zh: { prompt: "是什么把水面吹皱了？", options: [{ icon: "wind", correct: true, label: "风" }, { icon: "rain", label: "雨" }, { icon: "frog", label: "青蛙" }] },
        en: { prompt: "What wrinkled the water?", options: [{ icon: "wind", correct: true, label: "The wind" }, { icon: "rain", label: "The rain" }, { icon: "frog", label: "A frog" }] },
      },
      spots: [{ x: 0.5, y: 0.66, zh: "涟漪", en: "ripples" }],
      sticker: "🍃",
    },
    /* ---------------- 6 ---------------- */
    {
      scene: "p6",
      zh: ["下雨了。", "小蜗牛躲到叶子下面，听雨点滴滴答答。"],
      en: ["Then it began to rain.", "Little Snail hid under a leaf and listened: drip, drip, drip."],
      fact: {
        zh: { title: "蜗牛最喜欢的天气", body: "蜗牛的身体很容易变干，湿湿的下雨天对它们来说最舒服。" },
        en: { title: "A snail's favourite weather", body: "A snail's body dries out easily, so damp, rainy days suit them best." },
      },
      words: [
        { zh: "滴滴答答", en: "patter", def: { zh: "雨点落在叶子上的声音。", en: "The sound rain makes on leaves." } },
      ],
      quiz: {
        zh: { prompt: "小蜗牛喜欢什么天气？", options: [{ icon: "rain", correct: true, label: "下雨" }, { icon: "sun", label: "大太阳" }, { icon: "wind", label: "刮大风" }] },
        en: { prompt: "What weather does Little Snail like?", options: [{ icon: "rain", correct: true, label: "Rain" }, { icon: "sun", label: "Hot sun" }, { icon: "wind", label: "Strong wind" }] },
      },
      spots: [
        { x: 0.24, y: 0.44, zh: "雨滴", en: "raindrops" },
        { x: 0.68, y: 0.24, zh: "叶子", en: "the leaf" },
      ],
      sticker: "💧",
    },
    /* ---------------- 7 ---------------- */
    {
      scene: "p7",
      zh: ["雨停了。", "小水洼里，月亮又出现了，安安静静地等着他。"],
      en: ["The rain stopped.", "In a little puddle, the moon appeared again — waiting quietly."],
      fact: {
        zh: { title: "水洼会慢慢变小", body: "水洼里的水会一点点变成水汽，跑到空气里，所以过一会儿就变小了。" },
        en: { title: "Puddles shrink", body: "Water in a puddle slowly turns into vapour and rises into the air, so the puddle gets smaller." },
      },
      words: [
        { zh: "水洼", en: "puddle", def: { zh: "雨后留在地上的一小片水。", en: "A small pool of water left after rain." } },
      ],
      quiz: {
        zh: { prompt: "小水洼为什么会变小？", options: [{ icon: "drop", correct: true, label: "水跑进空气里了" }, { icon: "frog", label: "被喝掉了" }, { icon: "stone", label: "被搬走了" }] },
        en: { prompt: "Why does the puddle shrink?", options: [{ icon: "drop", correct: true, label: "The water rises into the air" }, { icon: "frog", label: "Somebody drank it" }, { icon: "stone", label: "Somebody moved it" }] },
      },
      spots: [{ x: 0.52, y: 0.74, zh: "水洼里的月亮", en: "the moon in the puddle" }],
      sticker: "✨",
    },
    /* ---------------- 8 ---------------- */
    {
      scene: "p8",
      zh: ["小蜗牛明白了：月亮一直都在，只是要换一个地方看。", "他缩进壳里，睡得香香的。"],
      en: ["Little Snail understood: the moon was always there — you just have to look from somewhere else.", "He tucked himself into his shell and slept, warm and happy."],
      fact: {
        zh: { title: "壳上的圈圈", body: "蜗牛壳跟着身体一起长大，一圈一圈长出来，像树的年轮。" },
        en: { title: "Rings on the shell", body: "A snail's shell grows with the snail, adding ring after ring, like the rings inside a tree." },
      },
      words: [
        { zh: "壳", en: "shell", def: { zh: "蜗牛背上硬硬的房子，可以躲进去休息。", en: "The hard little house on a snail's back." } },
      ],
      quiz: {
        zh: { prompt: "蜗牛壳上的圈圈是什么？", options: [{ icon: "shell", correct: true, label: "长大的痕迹" }, { icon: "leaf", label: "画上去的" }, { icon: "stone", label: "裂开的缝" }] },
        en: { prompt: "What are the rings on the shell?", options: [{ icon: "shell", correct: true, label: "Marks of growing" }, { icon: "leaf", label: "Painted on" }, { icon: "stone", label: "Cracks" }] },
      },
      spots: [
        { x: 0.49, y: 0.8, zh: "壳", en: "the shell" },
        { x: 0.74, y: 0.2, zh: "月亮", en: "the moon" },
      ],
      sticker: "🐌",
    },
  ],
};

/* 书架元数据：App 是通用伴读工具，这里是第一本书 */
BOOK.author = { zh: "伴读小组", en: "Team Ban Du" };
BOOK.age = "3–6";
BOOK.cover = "cover";
BOOK.accent = "#E09A45";
BOOK.tag = { zh: "睡前故事", en: "Bedtime story" };

const BOOKS = [BOOK];
