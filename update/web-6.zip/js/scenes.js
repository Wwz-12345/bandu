/* ============================================================
   scenes.js — original vector artwork for the book
   Every scene is a self-contained SVG string (no external assets),
   so the book stays tiny, offline and infinitely sharp.
   ============================================================ */

const SCENE_VB = "0 0 400 500";

/* ---------- deterministic helpers ---------- */
function rng(seed) {
  let s = seed >>> 0;
  return () => {
    s = (s * 1664525 + 1013904223) >>> 0;
    return s / 4294967296;
  };
}

function stars(n, seed, maxY = 330) {
  const r = rng(seed);
  let out = "";
  for (let i = 0; i < n; i++) {
    const x = (r() * 400).toFixed(1);
    const y = (r() * maxY).toFixed(1);
    const rad = (0.5 + r() * 1.25).toFixed(2);
    const o = (0.25 + r() * 0.65).toFixed(2);
    out += `<circle cx="${x}" cy="${y}" r="${rad}" fill="#fff" opacity="${o}"/>`;
  }
  return out;
}

function defs(uid) {
  return `<defs>
    <linearGradient id="${uid}-sky" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#0A1226"/>
      <stop offset="52%" stop-color="#18284C"/>
      <stop offset="100%" stop-color="#33496E"/>
    </linearGradient>
    <radialGradient id="${uid}-glow">
      <stop offset="0" stop-color="#FFE7AE" stop-opacity=".55"/>
      <stop offset="42%" stop-color="#FFDF95" stop-opacity=".16"/>
      <stop offset="100%" stop-color="#FFDF95" stop-opacity="0"/>
    </radialGradient>
    <radialGradient id="${uid}-moon" cx="36%" cy="32%">
      <stop offset="0" stop-color="#FFFAE8"/>
      <stop offset="68%" stop-color="#FFEAB6"/>
      <stop offset="100%" stop-color="#F3CB80"/>
    </radialGradient>
    <linearGradient id="${uid}-water" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#2A4768"/>
      <stop offset="100%" stop-color="#0E1C33"/>
    </linearGradient>
    <linearGradient id="${uid}-ground" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#1B2C48"/>
      <stop offset="100%" stop-color="#0B1424"/>
    </linearGradient>
    <linearGradient id="${uid}-beam" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#FFEBBE" stop-opacity=".85"/>
      <stop offset="100%" stop-color="#FFEBBE" stop-opacity="0"/>
    </linearGradient>
  </defs>`;
}

function svg(uid, inner) {
  return `<svg viewBox="${SCENE_VB}" preserveAspectRatio="xMidYMid slice" role="img" aria-hidden="true">${defs(
    uid
  )}${inner}</svg>`;
}

function moon(uid, cx, cy, r) {
  return `<g>
    <circle cx="${cx}" cy="${cy}" r="${r * 3.4}" fill="url(#${uid}-glow)"/>
    <circle cx="${cx}" cy="${cy}" r="${r}" fill="url(#${uid}-moon)"/>
    <circle cx="${cx - r * 0.28}" cy="${cy - r * 0.3}" r="${r * 0.15}" fill="#EED9A2" opacity=".55"/>
    <circle cx="${cx + r * 0.26}" cy="${cy + r * 0.24}" r="${r * 0.1}" fill="#EED9A2" opacity=".45"/>
    <circle cx="${cx + r * 0.06}" cy="${cy - r * 0.5}" r="${r * 0.07}" fill="#EED9A2" opacity=".4"/>
  </g>`;
}

function spiral(cx, cy, r0, turns, steps = 46) {
  let d = "";
  for (let i = 0; i <= steps; i++) {
    const k = i / steps;
    const a = k * turns * Math.PI * 2 - Math.PI / 2;
    const rr = r0 * k;
    d += (i ? " L" : "M") + (cx + Math.cos(a) * rr).toFixed(1) + " " + (cy + Math.sin(a) * rr).toFixed(1);
  }
  return d;
}

/* ---------- characters ---------- */
function snail(x, y, s = 1, opts = {}) {
  const { flip = false, asleep = false, glow = false } = opts;
  const tf = `translate(${x},${y}) scale(${flip ? -s : s},${s})`;
  const head = asleep
    ? `<path d="M14 -6 C24 -4 26 -12 22 -16 C19 -19 13 -18 12 -12 Z" fill="#F4E2C2"/>`
    : `<path d="M18 -7 C28 -9 32 -17 30 -25" stroke="#F4E2C2" stroke-width="4.6" fill="none" stroke-linecap="round"/>
       <circle cx="30.2" cy="-26" r="2.9" fill="#4C3116"/>
       <path d="M13 -8 C17 -14 17 -19 15 -23" stroke="#F4E2C2" stroke-width="3.8" fill="none" stroke-linecap="round"/>
       <circle cx="15" cy="-24" r="2.4" fill="#4C3116"/>`;
  const zzz = asleep
    ? `<g fill="#CFE0F5" opacity=".85" font-family="system-ui" font-weight="700">
         <text x="24" y="-30" font-size="9">z</text>
         <text x="31" y="-42" font-size="12">z</text>
         <text x="41" y="-58" font-size="15">Z</text>
       </g>`
    : "";
  return `<g transform="${tf}">
    <ellipse cx="0" cy="11" rx="42" ry="8" fill="#000" opacity=".28"/>
    <path d="M-38 4 C-42 -5 -34 -11 -26 -9 L10 -9 C19 -9 26 -2 26 4 C26 9 21 12 14 12 L-30 12 C-35 12 -37 8 -38 4 Z" fill="#F4E2C2"/>
    <path d="M-26 12 C-26 16 -20 18 -12 18" stroke="#D9C3A0" stroke-width="2" fill="none" opacity=".6"/>
    ${head}
    <circle cx="-5" cy="-15" r="20.5" fill="#D9904C"/>
    <circle cx="-5" cy="-15" r="20.5" fill="none" stroke="#B06B31" stroke-width="1.4"/>
    <path d="${spiral(-5, -15, 18.5, 2.55)}" stroke="#8A4E2B" stroke-width="2.3" fill="none" stroke-linecap="round" opacity=".92"/>
    ${glow ? `<circle cx="-5" cy="-15" r="26" fill="#FFE7AE" opacity=".12"/>` : ""}
    ${zzz}
  </g>`;
}

function ladybird(x, y, s = 1, rot = 0) {
  return `<g transform="translate(${x},${y}) rotate(${rot}) scale(${s})">
    <ellipse cx="0" cy="2" rx="15" ry="12" fill="#D9553F"/>
    <ellipse cx="0" cy="2" rx="15" ry="12" fill="none" stroke="#A63A29" stroke-width="1.2"/>
    <path d="M0 -10 L0 13" stroke="#2A2118" stroke-width="1.8"/>
    <circle cx="-6" cy="-2" r="3.1" fill="#2A2118"/>
    <circle cx="6" cy="0" r="3.4" fill="#2A2118"/>
    <circle cx="-5" cy="8" r="2.6" fill="#2A2118"/>
    <circle cx="6" cy="9" r="2.3" fill="#2A2118"/>
    <circle cx="0" cy="-12" r="6.4" fill="#2A2118"/>
    <path d="M-3 -17 L-6 -22" stroke="#2A2118" stroke-width="1.6" stroke-linecap="round"/>
    <path d="M3 -17 L6 -22" stroke="#2A2118" stroke-width="1.6" stroke-linecap="round"/>
  </g>`;
}

function frog(x, y, s = 1) {
  return `<g transform="translate(${x},${y}) scale(${s})">
    <ellipse cx="0" cy="12" rx="24" ry="7" fill="#000" opacity=".25"/>
    <ellipse cx="0" cy="0" rx="22" ry="17" fill="#79AE73"/>
    <ellipse cx="-14" cy="-4" rx="7" ry="4" fill="#93C08B" opacity=".7"/>
    <circle cx="-9" cy="-15" r="8" fill="#8CBB84"/>
    <circle cx="9" cy="-15" r="8" fill="#8CBB84"/>
    <circle cx="-9" cy="-16" r="4.4" fill="#fff"/>
    <circle cx="9" cy="-16" r="4.4" fill="#fff"/>
    <circle cx="-9" cy="-16" r="2.3" fill="#22331E"/>
    <circle cx="9" cy="-16" r="2.3" fill="#22331E"/>
    <path d="M-6 3 C-2 8 2 8 6 3" stroke="#3F6139" stroke-width="2" fill="none" stroke-linecap="round"/>
    <ellipse cx="-20" cy="10" rx="7" ry="4" fill="#6C9E66"/>
    <ellipse cx="20" cy="10" rx="7" ry="4" fill="#6C9E66"/>
  </g>`;
}

function leaf(cx, cy, w = 60, rot = -18, fill = "#2C4A64") {
  return `<g transform="translate(${cx},${cy}) rotate(${rot})">
    <path d="M${-w / 2} 0 Q 0 ${-w * 0.56} ${w / 2} 0 Q 0 ${w * 0.56} ${-w / 2} 0 Z" fill="${fill}"/>
    <path d="M${-w / 2} 0 L${w / 2} 0" stroke="#12241A" stroke-width="1.5" opacity=".5"/>
    <path d="M${-w / 2} 0 Q 0 ${-w * 0.56} ${w / 2} 0" fill="none" stroke="#EAF6EC" stroke-opacity=".16" stroke-width="2.4"/>
  </g>`;
}

function blade(x, baseY, h, lean = 0, fill = "#16273F", w = 1) {
  const tipX = x + lean;
  return `<path d="M${x} ${baseY} C${x + lean * 0.3} ${baseY - h * 0.55} ${tipX - lean * 0.15} ${
    baseY - h * 0.85
  } ${tipX} ${baseY - h}" stroke="${fill}" stroke-width="${w}" fill="none" stroke-linecap="round"/>`;
}

function grass(x0, x1, baseY, count, seed, fill = "#16273F", hMax = 90) {
  const r = rng(seed);
  let out = "";
  for (let i = 0; i < count; i++) {
    const x = x0 + r() * (x1 - x0);
    const h = hMax * (0.4 + r() * 0.6);
    const lean = (r() - 0.5) * 34;
    out += blade(x, baseY, h, lean, fill, 2 + r() * 2.2);
  }
  return out;
}

function flower(x, y, s = 1, petal = "#C9A6C0") {
  return `<g transform="translate(${x},${y}) scale(${s})">
    <path d="M0 0 L0 34" stroke="#1D3550" stroke-width="2.4" stroke-linecap="round"/>
    <g fill="${petal}" opacity=".9">
      <circle cx="0" cy="-7" r="5"/><circle cx="7" cy="0" r="5"/>
      <circle cx="0" cy="7" r="5"/><circle cx="-7" cy="0" r="5"/>
    </g>
    <circle cx="0" cy="0" r="3.4" fill="#FFE3A6"/>
  </g>`;
}

function firefly(x, y, s = 1, o = 1) {
  return `<g transform="translate(${x},${y}) scale(${s})" opacity="${o}">
    <circle r="12" fill="#FFE89B" opacity=".14"/>
    <circle r="6" fill="#FFE89B" opacity=".26"/>
    <circle r="2.4" fill="#FFF6D2"/>
  </g>`;
}

function hills(uid, y = 300) {
  return `<path d="M0 ${y + 24} C70 ${y - 26} 130 ${y + 18} 200 ${y - 6} C270 ${y - 30} 330 ${y + 14} 400 ${y - 12} L400 500 L0 500 Z" fill="#13223A"/>
    <path d="M0 ${y + 58} C80 ${y + 16} 150 ${y + 52} 220 ${y + 30} C290 ${y + 8} 340 ${y + 46} 400 ${y + 26} L400 500 L0 500 Z" fill="url(#${uid}-ground)"/>`;
}

/* ---------- scenes ---------- */
const SCENES = {
  /* 1 · the garden at night, snail on a leaf */
  p1(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(70, 11)}
       ${moon(uid, 302, 132, 25)}
       ${hills(uid, 288)}
       ${grass(0, 400, 430, 26, 3, "#0E1B2E", 120)}
       ${flower(84, 392, 1.05, "#B79DC0")}
       ${flower(336, 400, 0.9, "#C9A6C0")}
       ${leaf(150, 424, 148, -7, "#2F5A48")}
       ${leaf(150, 420, 104, 5, "#3B6D57")}
       ${snail(140, 400, 1.1, { flip: false })}
       ${firefly(74, 268, 1)}
       ${firefly(338, 300, 0.75, 0.9)}
       ${firefly(262, 356, 0.6, 0.8)}
       ${grass(0, 400, 500, 16, 9, "#0A1424", 70)}`
    );
  },

  /* 2 · a very big moon, a very small snail */
  p2(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(50, 23, 380)}
       ${moon(uid, 200, 168, 86)}
       <path d="M0 402 C90 376 150 404 220 388 C290 372 350 400 400 386 L400 500 L0 500 Z" fill="#12213A"/>
       <ellipse cx="200" cy="452" rx="120" ry="16" fill="#0A1424" opacity=".7"/>
       ${grass(0, 400, 470, 20, 5, "#0D1A2C", 60)}
       ${snail(200, 448, 0.82, {})}
       ${firefly(60, 300, 0.7, 0.85)}
       ${firefly(350, 340, 0.9, 0.9)}`
    );
  },

  /* 3 · ladybird on a stem */
  p3(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(55, 31)}
       ${moon(uid, 62, 126, 20)}
       ${hills(uid, 296)}
       ${grass(0, 400, 430, 22, 13, "#0F1D30", 130)}
       <path d="M300 430 C288 360 304 300 292 250" stroke="#1C3550" stroke-width="7" fill="none" stroke-linecap="round"/>
       ${leaf(282, 322, 92, -30, "#3B6D57")}
       ${leaf(168, 404, 124, -6, "#3B6D57")}
       ${snail(140, 386, 1.06, { flip: false })}
       ${ladybird(286, 302, 1.35, -10)}
       ${grass(0, 400, 500, 14, 17, "#0A1424", 74)}`
    );
  },

  /* 4 · the pond and the frog */
  p4(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(48, 41, 280)}
       ${moon(uid, 318, 96, 23)}
       <path d="M0 296 C80 278 152 298 224 288 C292 280 350 296 400 288 L400 344 L0 344 Z" fill="#16273F"/>
       <path d="M0 330 C110 322 250 338 400 328 L400 500 L0 500 Z" fill="url(#${uid}-water)"/>
       <g fill="#FFEFC6">
         <ellipse cx="300" cy="392" rx="17" ry="3.2" opacity=".8"/>
         <ellipse cx="300" cy="406" rx="13" ry="2.8" opacity=".58"/>
         <ellipse cx="300" cy="420" rx="10" ry="2.4" opacity=".42"/>
         <ellipse cx="300" cy="434" rx="7" ry="2" opacity=".28"/>
         <ellipse cx="300" cy="448" rx="4.5" ry="1.7" opacity=".17"/>
       </g>
       <ellipse cx="300" cy="390" rx="30" ry="56" fill="#FFE7AE" opacity=".07"/>
       <path d="M30 364 C120 356 220 364 330 358" stroke="#4A6B8E" stroke-width="1.4" opacity=".35" fill="none"/>
       <path d="M12 440 C120 432 240 440 386 432" stroke="#3C5A7C" stroke-width="1.2" opacity=".28" fill="none"/>
       <g>
         <ellipse cx="286" cy="372" rx="44" ry="15" fill="#2F5B4A"/>
         <ellipse cx="286" cy="372" rx="44" ry="15" fill="none" stroke="#3E7259" stroke-width="1.4"/>
         <path d="M264 372 L308 372" stroke="#3E7259" stroke-width="1.2" opacity=".7"/>
       </g>
       ${frog(286, 354, 1.04)}
       ${leaf(96, 376, 96, -7, "#3B6D57")}
       ${snail(92, 356, 0.98, {})}
       ${grass(0, 62, 344, 6, 19, "#132239", 54)}
       ${grass(336, 400, 344, 6, 23, "#132239", 50)}`
    );
  },

  /* 5 · wind breaks the water */
  p5(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(40, 53, 220)}
       ${moon(uid, 300, 70, 20)}
       <rect y="272" width="400" height="228" fill="url(#${uid}-water)"/>
       <g stroke="#4D7196" fill="none" opacity=".55">
         <ellipse cx="180" cy="330" rx="70" ry="14"/>
         <ellipse cx="180" cy="330" rx="118" ry="26"/>
         <ellipse cx="180" cy="330" rx="166" ry="40"/>
         <ellipse cx="180" cy="330" rx="214" ry="54" opacity=".5"/>
       </g>
       <g fill="#FFEFC6" opacity=".78">
         <ellipse cx="150" cy="326" rx="16" ry="4"/>
         <ellipse cx="196" cy="336" rx="12" ry="3.2"/>
         <ellipse cx="128" cy="340" rx="9" ry="2.6"/>
         <ellipse cx="168" cy="352" rx="18" ry="3.4" opacity=".6"/>
         <ellipse cx="212" cy="318" rx="7" ry="2.2" opacity=".7"/>
       </g>
       <g stroke="#BFD7F0" stroke-width="2" fill="none" opacity=".38" stroke-linecap="round">
         <path d="M46 214 C96 200 140 214 188 202"/>
         <path d="M60 244 C112 230 152 244 204 232"/>
         <path d="M232 178 C286 166 328 180 376 168"/>
       </g>
       ${leaf(330, 232, 44, 28, "#33556F")}
       ${leaf(56, 150, 38, -34, "#2A4760")}
       ${grass(0, 400, 500, 18, 29, "#0B1728", 90)}`
    );
  },

  /* 6 · rain and a leaf umbrella */
  p6(uid) {
    const r = rng(61);
    let rain = "";
    for (let i = 0; i < 34; i++) {
      const x = r() * 420 - 10;
      const y = r() * 400 - 40;
      const len = 26 + r() * 34;
      const o = (0.18 + r() * 0.4).toFixed(2);
      const w = 1.4 + r() * 1.4;
      rain += `<path d="M${x.toFixed(0)} ${y.toFixed(0)} l5 ${len.toFixed(0)}" stroke="#A8C6DF" stroke-width="${w.toFixed(
        1
      )}" stroke-linecap="round" opacity="${o}"/>`;
    }
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(14, 61, 200)}
       <path d="M250 -30 C250 -30 258 40 262 90" stroke="#1B3527" stroke-width="7" fill="none" stroke-linecap="round"/>
       ${leaf(250, 84, 470, 9, "#22402F")}
       ${leaf(250, 62, 330, -4, "#2B4E3A")}
       ${rain}
       <path d="M0 392 C90 378 150 398 220 388 C290 378 350 396 400 386 L400 500 L0 500 Z" fill="#0F1E33"/>
       <ellipse cx="238" cy="452" rx="104" ry="15" fill="#2A4768" opacity=".8"/>
       <path d="M150 452 C190 444 280 444 322 452" stroke="#7FA6C8" stroke-width="2" fill="none" opacity=".45"/>
       <g stroke="#9FC0DA" stroke-width="1.6" fill="none" opacity=".3">
         <path d="M186 424 c6 -7 14 -7 20 0"/>
         <path d="M286 428 c6 -7 14 -7 20 0"/>
       </g>
       ${snail(232, 420, 1.02, {})}
       ${grass(0, 400, 500, 12, 37, "#0A1424", 62)}`
    );
  },

  /* 7 · the puddle keeps the moon */
  p7(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(58, 71)}
       ${moon(uid, 322, 82, 24)}
       <path d="M0 356 C80 336 150 360 220 348 C290 336 350 356 400 344 L400 500 L0 500 Z" fill="#13233B"/>
       <ellipse cx="200" cy="420" rx="134" ry="48" fill="#28456B"/>
       <ellipse cx="200" cy="420" rx="134" ry="48" fill="none" stroke="#4A6E95" stroke-width="1.6" opacity=".55"/>
       <ellipse cx="200" cy="418" rx="118" ry="38" fill="#31527B" opacity=".85"/>
       <ellipse cx="200" cy="412" rx="30" ry="17" fill="#FFE7AE" opacity=".2"/>
       <ellipse cx="200" cy="410" rx="19" ry="12" fill="#FFF6DA" opacity=".95"/>
       <ellipse cx="196" cy="406" rx="5" ry="3.4" fill="#F3DCA4" opacity=".8"/>
       <ellipse cx="206" cy="414" rx="3.6" ry="2.4" fill="#F3DCA4" opacity=".7"/>
       <ellipse cx="150" cy="430" rx="16" ry="4" fill="#9FC0DA" opacity=".16"/>
       <ellipse cx="256" cy="436" rx="12" ry="3" fill="#9FC0DA" opacity=".13"/>
       ${snail(96, 372, 1.0, { flip: true })}
       ${grass(0, 400, 480, 16, 43, "#0E1B2E", 78)}
       ${firefly(340, 300, 0.8, 0.85)}`
    );
  },

  /* 8 · asleep in his shell */
  p8(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(66, 83)}
       ${moon(uid, 286, 118, 44)}
       ${hills(uid, 300)}
       ${grass(0, 400, 430, 22, 47, "#0E1B2E", 110)}
       <ellipse cx="196" cy="432" rx="98" ry="22" fill="#0A1424" opacity=".65"/>
       ${leaf(196, 452, 150, -4, "#27455E")}
       ${snail(196, 430, 1.16, { asleep: true })}
       ${firefly(96, 320, 0.8, 0.8)}
       ${firefly(330, 268, 1, 0.9)}
       ${grass(0, 400, 500, 16, 53, "#0A1424", 70)}`
    );
  },


  /* 书架顶部横幅：白天的花园 */
  banner(uid) {
    return `<svg viewBox="0 0 400 160" preserveAspectRatio="xMidYMid slice" aria-hidden="true">
      <defs>
        <linearGradient id="${uid}-daysky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#FFF4DE"/>
          <stop offset="70%" stop-color="#FFE6BC"/>
          <stop offset="100%" stop-color="#FFDDA8"/>
        </linearGradient>
      </defs>
      <rect width="400" height="160" fill="url(#${uid}-daysky)"/>
      <circle cx="312" cy="46" r="60" fill="#FFE9B0" opacity=".55"/>
      <circle cx="312" cy="46" r="26" fill="#FFD07A"/>
      <g stroke="#FFD07A" stroke-width="3" stroke-linecap="round" opacity=".7">
        <path d="M312 6 L312 14"/><path d="M312 78 L312 86"/>
        <path d="M272 46 L280 46"/><path d="M344 46 L352 46"/>
        <path d="M284 18 L290 24"/><path d="M340 74 L346 80"/>
        <path d="M340 18 L334 24"/><path d="M284 74 L290 68"/>
      </g>
      <ellipse cx="118" cy="44" rx="34" ry="14" fill="#FFFDF6" opacity=".85"/>
      <ellipse cx="146" cy="38" rx="24" ry="16" fill="#FFFDF6" opacity=".9"/>
      <ellipse cx="92" cy="40" rx="20" ry="11" fill="#FFFDF6" opacity=".8"/>
      <path d="M0 116 C70 92 130 120 200 106 C270 92 330 116 400 100 L400 160 L0 160 Z" fill="#B7CE9C"/>
      <path d="M0 136 C80 118 150 142 220 130 C290 118 340 138 400 126 L400 160 L0 160 Z" fill="#9DBA85"/>
      ${grass(0, 400, 160, 16, 71, "#87A66F", 34)}
      ${flower(60, 132, 0.85, "#F3B0A8")}
      ${flower(346, 138, 0.75, "#E8B3D0")}
      ${snail(200, 128, 0.72, { flip: false })}
      ${firefly(262, 96, 0.7, 0.9)}
    </svg>`;
  },

  /* cover */
  cover(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(80, 97)}
       ${moon(uid, 276, 124, 58)}
       ${hills(uid, 306)}
       ${grass(0, 400, 430, 24, 59, "#0F1D30", 110)}
       <ellipse cx="152" cy="368" rx="86" ry="14" fill="#0A1424" opacity=".45"/>
       ${leaf(152, 376, 150, -6, "#2F5A48")}
       ${snail(148, 350, 1.3, {})}
       ${firefly(70, 262, 0.9, 0.9)}
       ${firefly(334, 296, 0.7, 0.8)}
       <rect y="392" width="400" height="110" fill="url(#${uid}-ground)" opacity=".45"/>`
    );
  },

  finish(uid) {
    return svg(
      uid,
      `<rect width="400" height="500" fill="url(#${uid}-sky)"/>
       ${stars(90, 103)}
       ${moon(uid, 200, 150, 56)}
       ${hills(uid, 330)}
       ${grass(0, 400, 430, 20, 67, "#0F1D30", 110)}
       <ellipse cx="200" cy="440" rx="90" ry="16" fill="#0A1424" opacity=".6"/>
       ${leaf(200, 452, 140, -4, "#2A4760")}
       ${snail(200, 432, 1.18, {})}
       ${firefly(96, 300, 1, 0.95)}
       ${firefly(316, 286, 0.85, 0.9)}
       ${firefly(150, 236, 0.6, 0.75)}`
    );
  },
};

/* ---------- small icons for quiz options ---------- */
const ICONS = {
  feeler: `<path d="M32 52 C30 40 26 30 20 22" stroke="#F4E2C2" stroke-width="5" fill="none" stroke-linecap="round"/>
    <path d="M32 52 C38 42 44 34 48 28" stroke="#F4E2C2" stroke-width="5" fill="none" stroke-linecap="round"/>
    <circle cx="20" cy="21" r="5" fill="#4C3116"/><circle cx="48" cy="27" r="5" fill="#4C3116"/>
    <ellipse cx="32" cy="56" rx="13" ry="5" fill="#D9904C"/>`,
  eye: `<ellipse cx="32" cy="34" rx="19" ry="14" fill="#FFF6E4"/><circle cx="32" cy="34" r="8" fill="#3F5170"/><circle cx="29" cy="31" r="3" fill="#fff"/>`,
  foot: `<path d="M20 46 C20 36 44 36 44 46 C44 54 20 54 20 46 Z" fill="#F4E2C2"/><path d="M24 46 L40 46" stroke="#D9C3A0" stroke-width="2"/>`,
  sun: `<circle cx="32" cy="32" r="14" fill="#FFD98A"/><g stroke="#FFD98A" stroke-width="3.4" stroke-linecap="round">
    <path d="M32 8 L32 14"/><path d="M32 50 L32 56"/><path d="M8 32 L14 32"/><path d="M50 32 L56 32"/>
    <path d="M15 15 L19 19"/><path d="M45 45 L49 49"/><path d="M49 15 L45 19"/><path d="M19 45 L15 49"/></g>`,
  moon: `<circle cx="32" cy="32" r="17" fill="#FFE9B4"/><circle cx="26" cy="26" r="4" fill="#EED9A2"/><circle cx="37" cy="37" r="3" fill="#EED9A2"/>`,
  star: `<path d="M32 12 L38 27 L54 28 L42 38 L46 53 L32 44 L18 53 L22 38 L10 28 L26 27 Z" fill="#FFE28F"/>`,
  wing: `<path d="M18 44 C14 28 30 14 46 18 C50 32 38 48 18 44 Z" fill="#E9EEF5"/><path d="M22 42 C26 32 34 24 44 21" stroke="#C2CEDC" stroke-width="2" fill="none"/>`,
  water: `<ellipse cx="32" cy="40" rx="22" ry="10" fill="#8FB6D6"/><ellipse cx="32" cy="40" rx="22" ry="10" fill="none" stroke="#5E86A8" stroke-width="2"/><ellipse cx="32" cy="39" rx="7" ry="3" fill="#FFF6D8"/>`,
  stone: `<ellipse cx="32" cy="42" rx="20" ry="12" fill="#8E8A80"/><ellipse cx="27" cy="38" rx="7" ry="4" fill="#A8A49A"/>`,
  frog: `<ellipse cx="32" cy="42" rx="18" ry="13" fill="#79AE73"/><circle cx="24" cy="27" r="7" fill="#8CBB84"/><circle cx="40" cy="27" r="7" fill="#8CBB84"/><circle cx="24" cy="27" r="3" fill="#22331E"/><circle cx="40" cy="27" r="3" fill="#22331E"/>`,
  wind: `<g stroke="#B9D2E8" stroke-width="3.4" fill="none" stroke-linecap="round"><path d="M10 24 C22 18 34 22 44 18"/><path d="M12 34 C28 28 40 32 54 26"/><path d="M16 44 C28 40 36 42 48 38"/></g>`,
  rain: `<g stroke="#9FC0DA" stroke-width="3.4" stroke-linecap="round"><path d="M18 18 L14 30"/><path d="M32 14 L28 26"/><path d="M46 20 L42 32"/><path d="M24 36 L20 48"/><path d="M40 38 L36 50"/></g>`,
  leaf: `<path d="M14 44 C14 26 34 14 52 20 C50 38 34 50 14 44 Z" fill="#5C8C74"/><path d="M16 42 C26 34 38 26 50 21" stroke="#3F6A56" stroke-width="2" fill="none"/>`,
  shell: `<circle cx="32" cy="32" r="18" fill="#D9904C"/><path d="M32 32 C32 26 36 24 38 26 C40 29 36 33 32 32 C28 31 24 26 26 22 C29 17 40 16 44 22" stroke="#8A4E2B" stroke-width="2.4" fill="none" stroke-linecap="round"/>`,
  drop: `<path d="M32 12 C32 12 46 30 46 38 C46 45 40 50 32 50 C24 50 18 45 18 38 C18 30 32 12 32 12 Z" fill="#8FB6D6"/><circle cx="27" cy="36" r="3.4" fill="#DCEBF7"/>`,
};

function icon(name, size = 62) {
  const body = ICONS[name] || ICONS.moon;
  return `<svg viewBox="0 0 64 64" width="${size}" height="${size}" aria-hidden="true">${body}</svg>`;
}

