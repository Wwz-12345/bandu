/* ============================================================
   app.js — shelf · reader · read-along · discover · settings
   ============================================================ */
(function () {
  "use strict";

  const KEY = "lsm.v1";
  const screenEl = document.getElementById("screen");
  const synth = "speechSynthesis" in window ? window.speechSynthesis : null;
  let voices = [];

  /* ---------------- state ---------------- */
  const state = {
    lang: "zh",
    page: 0,
    rate: 1,
    subs: true,
    auto: true,
    stickers: [],
    screen: "shelf",
    voiceOk: true,
  };

  try {
    const saved = JSON.parse(localStorage.getItem(KEY) || "{}");
    ["lang", "page", "rate", "subs", "auto", "stickers"].forEach((k) => {
      if (saved[k] !== undefined) state[k] = saved[k];
    });
  } catch (e) {}
  if (!Array.isArray(state.stickers)) state.stickers = [];
  window.state = state; // i18n.js reads the active language from here

  window.addEventListener("error", (e) => {
    console.error("[app]", e.message, e.filename + ":" + e.lineno);
  });

  function save() {
    try {
      localStorage.setItem(
        KEY,
        JSON.stringify({
          lang: state.lang,
          page: state.page,
          rate: state.rate,
          subs: state.subs,
          auto: state.auto,
          stickers: state.stickers,
        })
      );
    } catch (e) {}
  }

  const PAGES = BOOK.pages;
  const LAST = PAGES.length - 1;

  /* ---------------- icons ---------------- */
  const IC = {
    back: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M15 5l-7 7 7 7"/></svg>',
    book: '<svg viewBox="0 0 24 24" width="19" height="19" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M3.5 6.2c0-.7.6-1.2 1.3-1.1l5.7.9V19l-5.7-.9c-.7-.1-1.3-.7-1.3-1.4z"/><path d="M20.5 6.2c0-.7-.6-1.2-1.3-1.1l-5.7.9V19l5.7-.9c.7-.1 1.3-.7 1.3-1.4z"/></svg>',
    gear: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .3 1.9l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.7 1.7 0 0 0-1.9-.3 1.7 1.7 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.7 1.7 0 0 0-1.1-1.5 1.7 1.7 0 0 0-1.9.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.7 1.7 0 0 0 .3-1.9 1.7 1.7 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.7 1.7 0 0 0 1.5-1.1 1.7 1.7 0 0 0-.3-1.9l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.7 1.7 0 0 0 1.9.3H9a1.7 1.7 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.7 1.7 0 0 0 1 1.5 1.7 1.7 0 0 0 1.9-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.7 1.7 0 0 0-.3 1.9V9a1.7 1.7 0 0 0 1.5 1H21a2 2 0 1 1 0 4h-.1a1.7 1.7 0 0 0-1.5 1z"/></svg>',
    play: '<svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor"><path d="M8 5.4c0-.9 1-1.5 1.8-1l9 6.6c.7.5.7 1.5 0 2l-9 6.6c-.8.5-1.8 0-1.8-1V5.4z"/></svg>',
    pause: '<svg viewBox="0 0 24 24" width="26" height="26" fill="currentColor"><rect x="7" y="5" width="3.6" height="14" rx="1.4"/><rect x="13.4" y="5" width="3.6" height="14" rx="1.4"/></svg>',
    left: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 6l-6 6 6 6"/></svg>',
    right: '<svg viewBox="0 0 24 24" width="22" height="22" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 6l6 6-6 6"/></svg>',
    spark: '<svg viewBox="0 0 24 24" width="15" height="15" fill="currentColor"><path d="M12 2.6l1.7 5.2c.2.5.5.8 1 1L20 10.5l-5.3 1.7c-.5.2-.8.5-1 1L12 18.4l-1.7-5.2c-.2-.5-.5-.8-1-1L4 10.5l5.3-1.7c.5-.2.8-.5 1-1L12 2.6z"/></svg>',
    sound: '<svg viewBox="0 0 24 24" width="15" height="15" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 10v4h3l4 3V7l-4 3H4z"/><path d="M16 9a4 4 0 0 1 0 6"/></svg>',
    close: '<svg viewBox="0 0 24 24" width="20" height="20" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round"><path d="M6 6l12 12M18 6L6 18"/></svg>',
    check: '<svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"><path d="M4 12.5l5 5 11-11"/></svg>',
  };

  const PAGE_ICON = ["feeler", "moon", "wing", "water", "wind", "rain", "drop", "shell"];

  /* ---------------- tiny utils ---------------- */
  function esc(s) {
    return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  }
  function $(sel) {
    return screenEl.querySelector(sel);
  }
  function toast(msg) {
    const old = screenEl.querySelector(".toast");
    if (old) old.remove();
    const el = document.createElement("div");
    el.className = "toast";
    el.textContent = msg;
    screenEl.appendChild(el);
    setTimeout(() => el.remove(), 2400);
  }
  function label(obj) {
    return state.lang === "zh" ? obj.zh : obj.en;
  }

  /* ---------------- speech ---------------- */
  let playToken = 0;
  let silentTimer = null;
  let playing = false;

  function refreshVoices() {
    if (!synth) return;
    voices = synth.getVoices() || [];
  }
  if (synth) {
    refreshVoices();
    synth.onvoiceschanged = refreshVoices;
    // warm up: some Android builds need one silent utterance to unlock
    try {
      const warm = new SpeechSynthesisUtterance(" ");
      warm.volume = 0;
      synth.speak(warm);
      synth.cancel();
    } catch (e) {}
  }

  function langTag() {
    return state.lang === "zh" ? "zh-CN" : "en-GB";
  }
  function pickVoice() {
    if (!voices.length) refreshVoices();
    const want = state.lang === "zh" ? "zh" : "en";
    return voices.find((v) => (v.lang || "").toLowerCase().replace("_", "-").startsWith(want));
  }
  function hasVoice() {
    if (!synth) return false;
    if (!voices.length) refreshVoices();
    return !!pickVoice();
  }

  function setActive(i) {
    const rows = screenEl.querySelectorAll(".sentence");
    rows.forEach((r, k) => r.classList.toggle("is-active", k === i));
  }
  function updatePlayUI() {
    const btn = $("#playBtn");
    if (!btn) return;
    btn.innerHTML = playing ? IC.pause : IC.play;
    btn.classList.toggle("is-playing", playing);
    btn.setAttribute("aria-label", playing ? t("pause") : t("play"));
  }

  function stopSpeech() {
    playToken++;
    playing = false;
    if (silentTimer) {
      clearTimeout(silentTimer);
      silentTimer = null;
    }
    if (synth) {
      try {
        synth.cancel();
      } catch (e) {}
    }
    setActive(-1);
    updatePlayUI();
  }

  function estimateMs(text) {
    if (state.lang === "zh") return 420 + text.length * 240;
    return 520 + text.split(/\s+/).length * 420;
  }

  function silentStep(token, i) {
    const lines = PAGES[state.page][state.lang];
    if (i >= lines.length) return finishSpeech(token);
    setActive(i);
    silentTimer = setTimeout(() => {
      if (token === playToken) silentStep(token, i + 1);
    }, estimateMs(lines[i]) / Math.max(0.6, state.rate));
  }

  function step(token, i) {
    if (token !== playToken) return;
    const lines = PAGES[state.page][state.lang];
    if (i >= lines.length) return finishSpeech(token);
    setActive(i);

    if (!synth || !hasVoice()) {
      if (!state.voiceOk) return silentStep(token, i);
      state.voiceOk = false;
      toast(t("toastNoVoice"));
      return silentStep(token, i);
    }

    const u = new SpeechSynthesisUtterance(lines[i]);
    u.lang = langTag();
    const v = pickVoice();
    if (v) u.voice = v;
    u.rate = state.rate;
    u.pitch = 1.06;
    u.onend = () => {
      if (token === playToken) step(token, i + 1);
    };
    u.onerror = () => {
      if (token === playToken) silentStep(token, i);
    };
    try {
      synth.speak(u);
    } catch (e) {
      silentStep(token, i);
    }
  }

  function finishSpeech(token) {
    if (token !== playToken) return;
    setActive(-1);
    playing = false;
    updatePlayUI();
    if (state.auto && state.page < LAST) {
      silentTimer = setTimeout(() => {
        if (token === playToken) goPage(state.page + 1, true);
      }, 1100);
    }
  }

  function startPlay(from) {
    if (synth) refreshVoices();
    playToken++;
    const token = playToken;
    playing = true;
    updatePlayUI();
    step(token, from || 0);
  }

  function speakWord(text) {
    if (silentTimer) {
      clearTimeout(silentTimer);
      silentTimer = null;
    }
    if (!synth || !hasVoice()) {
      toast(t("toastWord", text));
      return;
    }
    try {
      synth.cancel();
      const u = new SpeechSynthesisUtterance(text);
      u.lang = langTag();
      const v = pickVoice();
      if (v) u.voice = v;
      u.rate = Math.max(0.72, state.rate * 0.92);
      u.pitch = 1.12;
      synth.speak(u);
    } catch (e) {}
    toast(t("toastWord", text));
  }

  /* ---------------- navigation ---------------- */
  function goPage(i, autoplay) {
    stopSpeech();
    state.page = Math.max(0, Math.min(LAST, i));
    save();
    state.screen = "reader";
    render();
    if (autoplay) setTimeout(() => startPlay(0), 320);
  }

  function nextPage() {
    if (state.page >= LAST) {
      stopSpeech();
      state.screen = "finish";
      render();
      return;
    }
    goPage(state.page + 1);
  }

  /* ---------------- views ---------------- */
  function render() {
    document.documentElement.lang = state.lang === "zh" ? "zh-CN" : "en";
    document.documentElement.setAttribute("data-lang", state.lang);
    if (state.screen === "shelf") renderShelf();
    else if (state.screen === "reader") renderReader();
    else if (state.screen === "settings") renderSettings();
    else renderFinish();
  }

  function renderShelf() {
    const total = BOOK.pages.length;
    const readPage = state.page + 1;
    const opened = state.page > 0;
    const pct = Math.round((state.page / total) * 100);

    const cards = BOOKS.map((b, i) => {
      const isCurrent = i === 0;
      const ribbon = isCurrent && opened
        ? `<span class="book-ribbon">${t("progressShort", readPage, total)}</span>`
        : `<span class="book-ribbon is-new">${t("newBook")}</span>`;
      return `
      <button class="book" data-act="open-book" data-i="${i}"
        aria-label="${esc(b.title[state.lang])}，${t("bookPages", b.pages.length)}">
        <div class="book-cover">
          ${SCENES[b.cover || "cover"]("bk" + i)}
          ${ribbon}
          <div class="book-ink">
            <div class="book-title">${esc(b.title[state.lang])}</div>
            <div class="book-meta">${t("bookPages", b.pages.length)} · ${t("bookAge")}</div>
          </div>
        </div>
      </button>`;
    }).join("");

    screenEl.innerHTML = `
    <div class="view shelf is-entering">
      <header class="shelf-head">
        <div>
          <div class="brand-row">
            <span class="logo">${IC.book}</span>
            <h1 class="app-name">${t("appName")}</h1>
          </div>
          <p class="tagline">${t("tagline")}</p>
        </div>
        <button class="round-btn" data-act="open-settings" aria-label="${t("settings")}">${IC.gear}</button>
      </header>

      <div class="shelf-banner">${SCENES.banner("bn")}</div>

      <div class="shelf-body">
        <div class="shelf-label">
          <span>${t("shelfTitle")}</span>
          <span class="shelf-count">${t("shelfCount", BOOKS.length)}</span>
        </div>

        <div class="books-row">
          ${cards}
          <div class="book is-empty" aria-hidden="true">
            <div class="book-cover empty-cover">
              <span class="plus">＋</span>
              <span class="empty-label">${t("moreBooks")}</span>
              <span class="empty-sub">${t("comingSoon")}</span>
            </div>
          </div>
        </div>

        <div class="shelf-plank"></div>
        <p class="shelf-hint">${t("shelfHint")}</p>
      </div>
    </div>`;
  }

  function renderReader() {
    const p = PAGES[state.page];
    const lines = p[state.lang];
    const spots = p.spots || [];
    const dots = PAGES.map(
      (_, i) => `<span class="dot ${i === state.page ? "is-on" : ""} ${i < state.page ? "read" : ""}"></span>`
    ).join("");

    screenEl.innerHTML = `
    <div class="view reader is-entering">
      <div class="scene">
        ${SCENES[p.scene]("s" + state.page)}
        <div class="scene-fade"></div>
        ${spots
          .map(
            (s, i) =>
              `<button class="spot" data-act="spot" data-i="${i}" style="left:${s.x * 100}%;top:${
                s.y * 100
              }%" aria-label="${esc(label(s))}"></button>`
          )
          .join("")}
        <div class="topbar">
          <button class="icon-btn" data-act="back" aria-label="${t("back")}">${IC.back}</button>
          <div class="page-badge">${t("pageOf", state.page + 1, PAGES.length)}</div>
          <button class="icon-btn" data-act="open-settings" aria-label="${t("settings")}">${IC.gear}</button>
        </div>
      </div>

      <div class="panel">
        ${
          p.fact
            ? `<button class="discover" data-act="discover">${IC.spark}<span>${t("discover")}</span></button>`
            : ""
        }
        <div class="panel-grip"></div>
        <div class="sentences ${state.subs ? "" : "is-hidden"}" id="sentences">
          ${lines
            .map(
              (s, i) =>
                `<button class="sentence" data-act="sentence" data-i="${i}">${esc(s)}</button>`
            )
            .join("")}
        </div>
        <div class="controls">
          <button class="nav-btn" data-act="prev" aria-label="${t("prev")}" ${
            state.page === 0 ? "disabled" : ""
          }>${IC.left}</button>
          <button class="play-btn" data-act="play" id="playBtn" aria-label="${t("play")}">${IC.play}</button>
          <button class="nav-btn" data-act="next" aria-label="${t("next")}">${IC.right}</button>
        </div>
        <div class="dots">${dots}</div>
      </div>
    </div>`;
  }

  function renderSettings() {
    screenEl.innerHTML = `
    <div class="view settings is-entering">
      <div class="sheet-head">
        <button class="round-btn" data-act="back-settings" aria-label="${t("back")}">${IC.back}</button>
        <h1>${t("settingsTitle")}</h1>
      </div>

      <div class="set-group">
        <div class="set-group-label">${t("groupReading")}</div>
        <div class="set-card">
          <div class="set-row">
            <div>
              <div class="label">${t("langLabel")}</div>
              <div class="hint">${t("langHint")}</div>
            </div>
            <div class="segmented">
              <button data-act="lang" data-v="zh" class="${state.lang === "zh" ? "is-on" : ""}">中文</button>
              <button data-act="lang" data-v="en" class="${state.lang === "en" ? "is-on" : ""}">English</button>
            </div>
          </div>
          <div class="set-row">
            <div class="label">${t("rateLabel")}</div>
            <div class="segmented">
              <button data-act="rate" data-v="0.8" class="${state.rate === 0.8 ? "is-on" : ""}">0.8×</button>
              <button data-act="rate" data-v="1" class="${state.rate === 1 ? "is-on" : ""}">1.0×</button>
              <button data-act="rate" data-v="1.2" class="${state.rate === 1.2 ? "is-on" : ""}">1.2×</button>
            </div>
          </div>
          <div class="set-row">
            <div>
              <div class="label">${t("subsLabel")}</div>
              <div class="hint">${t("subsHint")}</div>
            </div>
            <button class="switch ${state.subs ? "is-on" : ""}" data-act="toggle-subs" aria-label="${t(
      "subsLabel"
    )}" aria-pressed="${state.subs}"></button>
          </div>
          <div class="set-row">
            <div>
              <div class="label">${t("autoLabel")}</div>
              <div class="hint">${t("autoHint")}</div>
            </div>
            <button class="switch ${state.auto ? "is-on" : ""}" data-act="toggle-auto" aria-label="${t(
      "autoLabel"
    )}" aria-pressed="${state.auto}"></button>
          </div>
        </div>
      </div>

      <div class="set-group">
        <div class="set-group-label">${t("groupProgress")}</div>
        <div class="set-card">
          <div class="set-row">
            <div class="label">${t("progressLabel")}</div>
            <div class="value">${t("pageOf", state.page + 1, PAGES.length)}</div>
          </div>
          <div class="set-row">
            <button class="label" style="color:#c4614a" data-act="restart">${t("restart")}</button>
          </div>
          <div class="set-row">
            <div class="label">${t("versionLabel")}</div>
            <button class="value" data-act="check-update">${versionText()} · ${t("checkUpdate")}</button>
          </div>
          ${
            window.AndroidBridge && AndroidBridge.updateBase
              ? `<div class="set-row server-row">
                   <div class="server-label">${t("updateBaseLabel")}</div>
                   <div class="server-url">${esc(AndroidBridge.updateBase())}</div>
                 </div>`
              : ""
          }
          <div class="set-row" id="updateRow" hidden>
            <div class="label" id="updateState"></div>
          </div>
        </div>
      </div>

      <div class="set-group">
        <div class="set-group-label">${t("groupAbout")}</div>
        <div class="about">${t("aboutText")}</div>
      </div>
    </div>`;
  }

  function renderFinish() {
    screenEl.innerHTML = `
    <div class="view finish is-entering">
      <div class="finish-art">${SCENES.finish("fn")}</div>
      <h1>${t("finishTitle")}</h1>
      <p>${t("finishDesc")}</p>
      <div class="stickers">
        ${PAGES.map(
          (p, i) =>
            `<div class="sticker ${state.stickers.includes(i) ? "" : "locked"}">${p.sticker}</div>`
        ).join("")}
      </div>
      <div style="width:100%;max-width:320px;margin-top:22px">
        <button class="cta" data-act="finish-again">${t("finishAgain")}</button>
        <button class="cta-ghost" data-act="finish-shelf">${t("finishShelf")}</button>
      </div>
    </div>`;
  }

  /* ---------------- overlays ---------------- */
  function openOverlay(html, cls) {
    closeOverlay(true);
    const el = document.createElement("div");
    el.className = "overlay";
    el.innerHTML = html;
    el.addEventListener("click", (e) => {
      if (e.target === el) closeOverlay();
    });
    screenEl.appendChild(el);
    return el;
  }

  function closeOverlay(instant) {
    const el = screenEl.querySelector(".overlay");
    if (!el) return;
    if (instant) {
      el.remove();
      return;
    }
    el.classList.add("is-closing");
    setTimeout(() => el.remove(), 200);
  }

  function openDiscover() {
    const p = PAGES[state.page];
    const f = label(p.fact);
    const words = p.words || [];
    const html = `
      <div class="sheet">
        <div class="sheet-grip"></div>
        <h2>${t("discoverTitle")}</h2>

        <div class="card">
          <div class="card-kicker">${IC.spark}${t("knowledge")}</div>
          <div class="card-title">${esc(f.title)}</div>
          <div class="card-text">${esc(f.body)}</div>
          <div class="card-illu">${icon(PAGE_ICON[state.page] || "moon", 96)}</div>
          <button class="quiz-cta small" data-act="listen-fact">${IC.sound}<span>${t("listen")}</span></button>
        </div>

        ${
          p.quiz
            ? `<button class="quiz-cta" data-act="open-quiz">${IC.spark}<span>${t(
                "quizEntry"
              )}</span></button>`
            : ""
        }

        ${
          words.length
            ? `<div class="card">
                 <div class="card-kicker">${IC.sound}${t("words")}</div>
                 <div class="word-list">
                   ${words
                     .map(
                       (w, i) =>
                         `<button class="word-chip" data-act="speak-word" data-i="${i}">
                            <span class="spk">${IC.sound}</span>${esc(
                           state.lang === "zh" ? w.zh : w.en
                         )}
                          </button>
                          <div class="word-def">${esc(label(w.def))}</div>`
                     )
                     .join("")}
                 </div>
               </div>`
            : ""
        }

        <button class="sheet-close" data-act="close-overlay">${t("close")}</button>
      </div>`;
    openOverlay(html);
  }

  function openQuiz() {
    const p = PAGES[state.page];
    const q = label(p.quiz);
    const html = `
      <div class="sheet">
        <div class="sheet-grip"></div>
        <h2>${t("quizTitle")}</h2>
        <div class="quiz-prompt">${esc(q.prompt)}</div>
        <div class="options" id="options">
          ${q.options
            .map(
              (o, i) =>
                `<button class="option" data-act="opt" data-i="${i}">
                   <span class="opt-illu" style="display:grid;place-items:center">${icon(o.icon, 54)}</span>
                   <span class="opt-label">${esc(o.label)}</span>
                 </button>`
            )
            .join("")}
        </div>
        <div id="fb"></div>
        <button class="sheet-close" data-act="close-overlay">${t("close")}</button>
      </div>`;
    openOverlay(html);
  }

  function answer(i) {
    const p = PAGES[state.page];
    const q = label(p.quiz);
    const opts = $("#options").querySelectorAll(".option");
    const chosen = q.options[i];
    const right = q.options.findIndex((o) => o.correct === true);
    opts.forEach((el, k) => {
      el.classList.remove("is-right", "is-wrong");
      if (k === right) el.classList.add("is-right");
      if (k === i && i !== right) el.classList.add("is-wrong");
    });
    const fb = $("#fb");
    if (i === right) {
      if (!state.stickers.includes(state.page)) {
        state.stickers.push(state.page);
        save();
      }
      fb.innerHTML = `<div class="feedback ok">${IC.check}<span>${t("correct")}</span></div>
        <button class="quiz-cta" data-act="close-overlay">${t("quizDone")}</button>`;
      speakWord(q.options[right].label);
    } else {
      fb.innerHTML = `<div class="feedback no"><span>${t("tryAgain")}</span></div>`;
    }
  }

  /* ---------------- 通用输入弹窗 ---------------- */
  function openPrompt(opts) {
    const el = document.createElement("div");
    el.className = "gate";
    el.innerHTML = `
      <div class="gate-card" style="text-align:left">
        <h3 style="text-align:center">${opts.title}</h3>
        <p style="text-align:center">${opts.hint || ""}</p>
        <input class="gate-input" id="promptInput" type="text" spellcheck="false" autocomplete="off"
               style="font-size:14px;height:50px;font-weight:600"
               value="${(opts.value || "").replace(/"/g, "&quot;")}">
        <div class="gate-actions">
          <button class="cancel" data-p="cancel">${t("gateCancel")}</button>
          <button class="ok" data-p="ok">${t("gateOk")}</button>
        </div>
      </div>`;
    screenEl.appendChild(el);
    const input = el.querySelector("#promptInput");
    setTimeout(() => input.focus(), 120);
    const close = () => el.remove();
    el.querySelector('[data-p="cancel"]').addEventListener("click", close);
    el.querySelector('[data-p="ok"]').addEventListener("click", () => {
      const v = input.value.trim();
      close();
      if (v) opts.onOk(v);
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") el.querySelector('[data-p="ok"]').click();
    });
  }

  /* ---------------- parent gate ---------------- */
  function openGate(onPass) {
    const a = 11 + Math.floor(Math.random() * 8);
    const b = 3 + Math.floor(Math.random() * 6);
    const el = document.createElement("div");
    el.className = "gate";
    el.innerHTML = `
      <div class="gate-card">
        <h3>${t("gateTitle")}</h3>
        <p>${t("gateDesc")}</p>
        <div class="gate-q">${t("gateQuestion", a, b)}</div>
        <input class="gate-input" type="number" inputmode="numeric" id="gateInput" aria-label="${t(
          "gateTitle"
        )}">
        <div class="gate-err" id="gateErr"></div>
        <div class="gate-actions">
          <button class="cancel" data-gate="cancel">${t("gateCancel")}</button>
          <button class="ok" data-gate="ok">${t("gateOk")}</button>
        </div>
      </div>`;
    screenEl.appendChild(el);
    const input = el.querySelector("#gateInput");
    setTimeout(() => input.focus(), 120);
    const close = () => el.remove();
    el.querySelector('[data-gate="cancel"]').addEventListener("click", close);
    el.querySelector('[data-gate="ok"]').addEventListener("click", () => {
      if (Number(input.value) === a + b) {
        close();
        onPass();
      } else {
        el.querySelector("#gateErr").textContent = t("gateWrong");
        input.value = "";
        input.focus();
      }
    });
    input.addEventListener("keydown", (e) => {
      if (e.key === "Enter") el.querySelector('[data-gate="ok"]').click();
    });
  }

  /* ---------------- actions ---------------- */
  screenEl.addEventListener("click", (e) => {
    const el = e.target.closest("[data-act]");
    if (!el) return;
    const act = el.dataset.act;
    const i = Number(el.dataset.i);

    switch (act) {
      case "open-book":
        goPage(state.page, false);
        break;
      case "start":
        goPage(state.page, false);
        break;
      case "back":
        stopSpeech();
        state.screen = "shelf";
        render();
        break;
      case "open-settings":
        stopSpeech();
        state.screen = "settings";
        render();
        break;
      case "back-settings":
        state.screen = state.page > 0 ? "reader" : "shelf";
        render();
        break;
      case "prev":
        if (state.page > 0) goPage(state.page - 1);
        break;
      case "next":
        nextPage();
        break;
      case "play":
        if (playing) stopSpeech();
        else startPlay(0);
        break;
      case "sentence":
        startPlay(i);
        break;
      case "spot": {
        const s = PAGES[state.page].spots[i];
        const old = screenEl.querySelector(".spot-label");
        if (old) old.remove();
        const b = document.createElement("div");
        b.className = "spot-label";
        b.style.left = s.x * 100 + "%";
        b.style.top = s.y * 100 + "%";
        b.textContent = label(s);
        $(".scene").appendChild(b);
        speakWord(label(s));
        setTimeout(() => b.remove(), 2200);
        break;
      }
      case "discover":
        openDiscover();
        break;
      case "open-quiz":
        openQuiz();
        break;
      case "opt":
        answer(i);
        break;
      case "close-overlay":
        closeOverlay();
        break;
      case "listen-fact": {
        const f = label(PAGES[state.page].fact);
        speakWord(f.title + "。" + f.body);
        break;
      }
      case "speak-word": {
        const w = PAGES[state.page].words[i];
        speakWord(state.lang === "zh" ? w.zh : w.en);
        break;
      }
      case "lang":
        state.lang = el.dataset.v;
        save();
        stopSpeech();
        render();
        break;
      case "rate":
        state.rate = Number(el.dataset.v);
        save();
        render();
        break;
      case "toggle-subs":
        state.subs = !state.subs;
        save();
        render();
        break;
      case "toggle-auto":
        state.auto = !state.auto;
        save();
        render();
        break;
      case "edit-update-base":
        openPrompt({
          title: t("updateBaseLabel"),
          hint: t("updateBaseHint"),
          value: (window.AndroidBridge && AndroidBridge.updateBase && AndroidBridge.updateBase()) || "",
          onOk: (v) => {
            if (window.AndroidBridge && AndroidBridge.setUpdateBase) {
              AndroidBridge.setUpdateBase(v.replace(/\/+$/, ""));
              toast(t("updateBaseSaved"));
              render();
            }
          },
        });
        break;
      case "check-update":
        checkUpdate();
        break;
      case "do-web-update":
        doWebUpdate(el.dataset.url, Number(el.dataset.code));
        break;
      case "do-apk-update":
        if (window.AndroidBridge && AndroidBridge.openUrl) AndroidBridge.openUrl(el.dataset.url);
        closeOverlay();
        break;
      case "restart-app":
        if (window.AndroidBridge && AndroidBridge.restart) AndroidBridge.restart();
        else location.reload();
        break;
      case "restart":
        openGate(() => {
          stopSpeech();
          state.page = 0;
          state.stickers = [];
          save();
          toast(t("restartDone"));
          state.screen = "reader";
          render();
        });
        break;
      case "finish-again":
        goPage(0);
        break;
      case "finish-shelf":
        state.page = 0;
        save();
        state.screen = "shelf";
        render();
        break;
    }
  });

  /* ---------------- swipe to turn pages ---------------- */
  let touchX = null;
  let touchY = null;
  screenEl.addEventListener(
    "touchstart",
    (e) => {
      if (!screenEl.querySelector(".reader")) return;
      const t = e.changedTouches[0];
      touchX = t.clientX;
      touchY = t.clientY;
    },
    { passive: true }
  );
  screenEl.addEventListener(
    "touchend",
    (e) => {
      if (touchX === null) return;
      const t = e.changedTouches[0];
      const dx = t.clientX - touchX;
      const dy = t.clientY - touchY;
      touchX = null;
      if (Math.abs(dx) < 46 || Math.abs(dx) < Math.abs(dy) * 1.4) return;
      if (screenEl.querySelector(".overlay") || screenEl.querySelector(".gate")) return;
      if (dx < 0) nextPage();
      else if (state.page > 0) goPage(state.page - 1);
    },
    { passive: true }
  );

  /* ---------------- version & update ---------------- */
  function versionText() {
    const v = window.APP_VERSION || { name: "1.0.0", code: 1 };
    return "v" + v.name;
  }

  function setUpdateState(msg) {
    const row = $("#updateRow");
    const box = $("#updateState");
    if (!row || !box) return;
    row.hidden = !msg;
    box.textContent = msg || "";
  }

  let silentUpdateCheck = false;

  function autoCheckUpdate() {
    if (window.AndroidBridge && AndroidBridge.checkUpdate) {
      silentUpdateCheck = true;
      try {
        AndroidBridge.checkUpdate();
      } catch (e) {
        silentUpdateCheck = false;
      }
    }
  }

  function checkUpdate() {
    if (window.AndroidBridge && AndroidBridge.checkUpdate) {
      setUpdateState(t("checking"));
      silentUpdateCheck = false;
      AndroidBridge.checkUpdate();
      return;
    }
    setUpdateState(t("webOnly"));
    toast(t("webOnly"));
  }

  function doWebUpdate(url, code) {
    if (!(window.AndroidBridge && AndroidBridge.applyWebUpdate)) return;
    setUpdateState(t("checking"));
    AndroidBridge.applyWebUpdate(url, code);
  }

  let updateMask = null;

  function showUpdateMask(text) {
    hideUpdateMask();
    updateMask = document.createElement("div");
    updateMask.className = "upd-mask";
    updateMask.innerHTML =
      '<div class="upd-card"><div class="spinner"></div><div class="upd-text">' + text + "</div></div>";
    screenEl.appendChild(updateMask);
  }

  function hideUpdateMask() {
    if (updateMask) {
      updateMask.remove();
      updateMask = null;
    }
  }

  /** 只有内容更新：直接更新，不弹窗、不让用户做选择 */
  function startContentUpdate(d) {
    showUpdateMask(t("updatingContent"));
    try {
      AndroidBridge.applyWebUpdate(d.base + "/" + d.web + "?v=" + d.webCode, d.webCode);
    } catch (e) {
      hideUpdateMask();
      toast(t("updateFail"));
    }
  }

  /** 只有需要新安装包时才弹窗 */
  function openApkSheet(d) {
    openOverlay(`
      <div class="sheet">
        <div class="sheet-grip"></div>
        <h2>${t("updateFound")} ${d.remoteName ? "v" + d.remoteName : ""}</h2>
        ${
          d.notes
            ? `<div class="card"><div class="card-kicker">${IC.spark}${t(
                "updateNotes"
              )}</div><div class="card-text" style="white-space:pre-line">${esc(d.notes)}</div></div>`
            : ""
        }
        <p class="upd-hint">${t("apkNeededHint")}</p>
        <button class="quiz-cta" data-act="do-apk-update" data-url="${d.base}/${d.apk}?v=${d.remoteCode}">${t(
      "downloadInstall"
    )}</button>
        <button class="sheet-close" data-act="close-overlay">${t("later")}</button>
      </div>`);
  }

  window.__androidUpdate = function (raw) {
    let d;
    try {
      d = JSON.parse(raw);
    } catch (e) {
      setUpdateState(t("updateFail"));
      return;
    }
    if (!d.ok) {
      setUpdateState(t("updateFail"));
      if (!silentUpdateCheck) toast(t("updateFail"));
      silentUpdateCheck = false;
      return;
    }

    const hasApk = d.remoteCode > d.localCode;
    const hasWeb = d.webCode > d.webVersion;
    const quiet = silentUpdateCheck;
    silentUpdateCheck = false;

    if (!hasApk && !hasWeb) {
      setUpdateState(t("upToDate"));
      if (!quiet) toast(t("upToDate"));
      return;
    }

    if (hasApk) {
      setUpdateState(t("updateFound") + " " + (d.remoteName || ""));
      if (quiet) {
        // 后台检查发现要换安装包：不打扰，只记一笔，等用户自己点检查更新
        setUpdateState(t("updateFound") + " " + (d.remoteName || ""));
      } else {
        openApkSheet(d);
      }
      return;
    }

    // 只有内容更新 → 直接更新
    setUpdateState(t("updatingContent"));
    startContentUpdate(d);
  };

  window.__androidWebUpdated = function (ok, msg) {
    if (!ok) {
      hideUpdateMask();
      setUpdateState(t("updateFail"));
      toast(t("updateFail"));
      return;
    }
    if (updateMask) {
      const txt = updateMask.querySelector(".upd-text");
      if (txt) txt.textContent = t("updatedRestart");
      const sp = updateMask.querySelector(".spinner");
      if (sp) sp.style.display = "none";
    }
    setUpdateState(t("updatedRestart"));
    setTimeout(() => {
      hideUpdateMask();
      if (window.AndroidBridge && AndroidBridge.restart) AndroidBridge.restart();
      else location.reload();
    }, 1000);
  };

  /* ---------------- boot ---------------- */
  // deep link: #p3 opens page 3 (handy for demos and for teachers)
  const deep = (location.hash || "").match(/^#p(\d+)$/);
  if (deep) {
    state.page = Math.max(0, Math.min(LAST, Number(deep[1]) - 1));
    state.screen = "reader";
  }
  render();
  setTimeout(autoCheckUpdate, 1200);

  if ("serviceWorker" in navigator && location.protocol.startsWith("http")) {
    window.addEventListener("load", () => {
      navigator.serviceWorker.register("sw.js").catch(() => {});
    });
  }
})();
