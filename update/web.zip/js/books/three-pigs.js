/* ============================================================
   《三只小猪》 The Three Little Pigs
   一本书 = 一个文件：文字、插画、问答全在这里。
   加新书：复制本文件 → 改内容 → 到 index.js 的 BOOK_FILES 加一行。
   ============================================================ */

(function () {
  "use strict";

  /* ---------------- 本地绘画零件 ---------------- */

  function wrap(uid, inner) {
    return `<svg viewBox="0 0 400 500" preserveAspectRatio="xMidYMid slice" role="img" aria-hidden="true">
      <defs>
        <linearGradient id="${uid}-dsky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0" stop-color="#CFE9F7"/>
          <stop offset="55%" stop-color="#E7F4FA"/>
          <stop offset="100%" stop-color="#FBF8EC"/>
        </linearGradient>
      </defs>${inner}</svg>`;
  }

  function skySun(uid) {
    return `<rect width="400" height="500" fill="url(#${uid}-dsky)"/>
      <circle cx="318" cy="76" r="62" fill="#FFE9A8" opacity=".45"/>
      <circle cx="318" cy="76" r="30" fill="#FFD675"/>`;
  }

  function cloud(cx, cy, s) {
    return `<g fill="#FFFFFF" opacity=".93">
      <ellipse cx="${cx}" cy="${cy}" rx="${30 * s}" ry="${13 * s}"/>
      <ellipse cx="${cx - 18 * s}" cy="${cy + 4 * s}" rx="${19 * s}" ry="${10 * s}"/>
      <ellipse cx="${cx + 20 * s}" cy="${cy + 3 * s}" rx="${17 * s}" ry="${9 * s}"/>
    </g>`;
  }

  function meadow(y, far) {
    return `<path d="M0 ${y} C80 ${y - 20} 150 ${y + 8} 220 ${y - 6} C290 ${y - 20} 350 ${y + 4} 400 ${y - 10} L400 500 L0 500 Z" fill="${far || "#A9D2A0"}"/>
      <path d="M0 ${y + 34} C90 ${y + 14} 160 ${y + 42} 240 ${y + 28} C310 ${y + 18} 360 ${y + 38} 400 ${y + 26} L400 500 L0 500 Z" fill="#86BB80"/>`;
  }

  function tuft(x, y, s) {
    return `<g stroke="#6FA76B" stroke-width="${2 * s}" fill="none" stroke-linecap="round">
      <path d="M${x} ${y} q -4 -${12 * s} -8 -${16 * s}"/>
      <path d="M${x} ${y} q 0 -${14 * s} 2 -${18 * s}"/>
      <path d="M${x} ${y} q 5 -${11 * s} 9 -${15 * s}"/>
    </g>`;
  }

  function pig(x, y, s, opts) {
    const flip = opts && opts.flip ? -1 : 1;
    return `<g transform="translate(${x},${y}) scale(${s * flip},${s})">
      <ellipse cx="0" cy="36" rx="42" ry="9" fill="#3B5A3A" opacity=".16"/>
      <path d="M-36 8 C-46 2 -46 -10 -36 -8" stroke="#EFA6B8" stroke-width="7" fill="none" stroke-linecap="round"/>
      <ellipse cx="0" cy="8" rx="37" ry="27" fill="#F7B8C8"/>
      <rect x="-25" y="24" width="13" height="17" rx="5" fill="#EFA6B8"/>
      <rect x="7" y="24" width="13" height="17" rx="5" fill="#EFA6B8"/>
      <circle cx="30" cy="-10" r="22" fill="#F9C3D1"/>
      <path d="M18 -27 L12 -45 L32 -33 Z" fill="#EFA6B8"/>
      <path d="M41 -29 L50 -44 L33 -35 Z" fill="#EFA6B8"/>
      <ellipse cx="43" cy="-7" rx="10" ry="8" fill="#EF93AA"/>
      <circle cx="39.5" cy="-8" r="1.7" fill="#8C4A5C"/>
      <circle cx="46" cy="-8" r="1.7" fill="#8C4A5C"/>
      <circle cx="24" cy="-17" r="2.4" fill="#7A3D4E"/>
      <circle cx="35" cy="-19" r="2.4" fill="#7A3D4E"/>
    </g>`;
  }

  function wolf(x, y, s, opts) {
    const flip = opts && opts.flip ? -1 : 1;
    return `<g transform="translate(${x},${y}) scale(${s * flip},${s})">
      <ellipse cx="0" cy="36" rx="44" ry="9" fill="#3B5A3A" opacity=".16"/>
      <path d="M-38 4 C-52 -2 -54 -18 -42 -20" stroke="#8B93A6" stroke-width="11" fill="none" stroke-linecap="round"/>
      <ellipse cx="0" cy="6" rx="40" ry="25" fill="#8B93A6"/>
      <rect x="-26" y="22" width="13" height="18" rx="5" fill="#767E92"/>
      <rect x="9" y="22" width="13" height="18" rx="5" fill="#767E92"/>
      <circle cx="32" cy="-13" r="21" fill="#98A0B3"/>
      <path d="M19 -30 L14 -49 L34 -36 Z" fill="#7E8699"/>
      <path d="M43 -32 L50 -49 L34 -38 Z" fill="#7E8699"/>
      <path d="M42 -8 q15 2 19 11 q-11 3 -19 -3 Z" fill="#AEB6C7"/>
      <circle cx="52" cy="0" r="3.2" fill="#3B4152"/>
      <circle cx="29" cy="-19" r="2.6" fill="#2E3444"/>
      <circle cx="40" cy="-20" r="2.6" fill="#2E3444"/>
      <path d="M46 8 l3 6 l3 -6" fill="#fff" opacity=".9"/>
    </g>`;
  }

  /* 房子：kind = straw / wood / brick */
  function house(kind, x, baseY, s) {
    const c =
      {
        straw: { wall: "#EFD08A", roof: "#D9AE55", line: "#C79A45" },
        wood: { wall: "#C79263", roof: "#A9714A", line: "#8E5C3A" },
        brick: { wall: "#C96A5B", roof: "#9E4A3E", line: "#8A3B31" },
      }[kind] || { wall: "#EFD08A", roof: "#D9AE55", line: "#C79A45" };

    const w = 150 * s;
    const h = 104 * s;
    const x0 = x - w / 2;
    const roofH = 62 * s;
    const topY = baseY - h;

    let texture = "";
    if (kind === "straw") {
      texture = `<g stroke="${c.line}" stroke-width="${1.4 * s}" opacity=".55">
        ${[0, 1, 2, 3, 4, 5]
          .map((i) => `<path d="M${x0 + 6 * s} ${topY + 16 * s + i * 15 * s} L${x0 + w - 6 * s} ${topY + 10 * s + i * 15 * s}"/>`)
          .join("")}
      </g>`;
    } else if (kind === "wood") {
      texture = `<g stroke="${c.line}" stroke-width="${2 * s}" opacity=".5">
        ${[1, 2, 3, 4, 5]
          .map((i) => `<path d="M${x0 + w * i / 6} ${topY} L${x0 + w * i / 6} ${baseY}"/>`)
          .join("")}
      </g>`;
    } else {
      let bricks = "";
      for (let row = 0; row < 5; row++) {
        const y = topY + 10 * s + row * 19 * s;
        bricks += `<path d="M${x0} ${y} L${x0 + w} ${y}" stroke="${c.line}" stroke-width="${1.6 * s}" opacity=".5"/>`;
        const off = row % 2 ? 0 : 1;
        for (let col = off; col < 5; col++) {
          const xb = x0 + (w / 5) * col + (w / 10);
          bricks += `<path d="M${xb} ${y} L${xb} ${y + 19 * s}" stroke="${c.line}" stroke-width="${1.4 * s}" opacity=".45"/>`;
        }
      }
      texture = bricks;
    }

    return `<g>
      <ellipse cx="${x}" cy="${baseY + 4 * s}" rx="${w * 0.62}" ry="${9 * s}" fill="#3B5A3A" opacity=".18"/>
      <rect x="${x0}" y="${topY}" width="${w}" height="${h}" rx="${6 * s}" fill="${c.wall}"/>
      ${texture}
      <path d="M${x0 - 14 * s} ${topY} L${x} ${topY - roofH} L${x0 + w + 14 * s} ${topY} Z" fill="${c.roof}"/>
      <path d="M${x0 - 14 * s} ${topY} L${x} ${topY - roofH} L${x0 + w + 14 * s} ${topY} Z" fill="none" stroke="${c.line}" stroke-width="${2 * s}" opacity=".6"/>
      <rect x="${x - 20 * s}" y="${baseY - 52 * s}" width="${40 * s}" height="${52 * s}" rx="${5 * s}" fill="${c.line}" opacity=".85"/>
      <circle cx="${x + 12 * s}" cy="${baseY - 28 * s}" r="${3 * s}" fill="#F6E3B8"/>
      <rect x="${x0 + 14 * s}" y="${topY + 20 * s}" width="${26 * s}" height="${26 * s}" rx="${4 * s}" fill="#FBF3DC" stroke="${c.line}" stroke-width="${2 * s}"/>
      <path d="M${x0 + 27 * s} ${topY + 20 * s} L${x0 + 27 * s} ${topY + 46 * s}" stroke="${c.line}" stroke-width="${1.6 * s}"/>
    </g>`;
  }

  function chimney(x, y, s) {
    return `<rect x="${x}" y="${y}" width="${18 * s}" height="${34 * s}" rx="${3 * s}" fill="#9E4A3E"/>
      <rect x="${x - 3 * s}" y="${y - 5 * s}" width="${24 * s}" height="${9 * s}" rx="${2 * s}" fill="#8A3B31"/>`;
  }

  function strawFly(cx, cy, s) {
    return `<g stroke="#D9AE55" stroke-width="${3 * s}" stroke-linecap="round" opacity=".9">
      <path d="M${cx} ${cy} l ${18 * s} ${-6 * s}"/>
      <path d="M${cx + 10 * s} ${cy + 12 * s} l ${20 * s} ${4 * s}"/>
      <path d="M${cx - 8 * s} ${cy + 20 * s} l ${14 * s} ${12 * s}"/>
    </g>`;
  }

  /* ---------------- 八个场景 ---------------- */

  Object.assign(SCENES, {
    /* 1 · 三只小猪在草地上 */
    pig1(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(96, 74, 1)}
         ${cloud(228, 52, 0.72)}
         ${meadow(300)}
         ${tuft(60, 400, 1)}
         ${tuft(340, 412, 1)}
         ${pig(130, 396, 0.82)}
         ${pig(210, 404, 0.9)}
         ${pig(292, 396, 0.82, { flip: true })}
         <g stroke="#6FA76B" stroke-width="3" stroke-linecap="round" opacity=".8">
           <path d="M40 470 q 10 -16 22 -20"/>
           <path d="M356 476 q -10 -16 -22 -20"/>
         </g>`
      );
    },

    /* 2 · 稻草房 */
    pig2(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(110, 66, 0.85)}
         ${meadow(306)}
         ${house("straw", 214, 400, 1.05)}
         ${pig(96, 408, 0.78, { flip: true })}
         ${strawFly(120, 330, 0.7)}
         ${tuft(60, 440, 1)}`
      );
    },

    /* 3 · 木头房 */
    pig3(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(268, 62, 0.8)}
         ${meadow(308)}
         ${house("wood", 208, 402, 1.05)}
         ${pig(98, 410, 0.78, { flip: true })}
         <g stroke="#8E5C3A" stroke-width="4" stroke-linecap="round" opacity=".8">
           <path d="M70 430 l 16 -10"/>
           <path d="M84 442 l 18 4"/>
         </g>
         ${tuft(330, 448, 1)}`
      );
    },

    /* 4 · 砖房 */
    pig4(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(100, 70, 0.9)}
         ${meadow(310)}
         ${house("brick", 216, 404, 1.06)}
         ${chimney(276, 246, 1.06)}
         ${pig(92, 414, 0.76, { flip: true })}
         <g fill="#C96A5B" stroke="#8A3B31" stroke-width="2">
           <rect x="58" y="432" width="30" height="16" rx="3"/>
           <rect x="58" y="452" width="30" height="16" rx="3"/>
           <rect x="92" y="442" width="30" height="16" rx="3"/>
         </g>`
      );
    },

    /* 5 · 狼吹倒稻草房 */
    pig5(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(300, 52, 0.7)}
         ${meadow(312)}
         <g transform="rotate(-8 210 400)">
           ${house("straw", 220, 404, 1.05)}
         </g>
         ${wolf(78, 402, 0.95)}
         <g stroke="#BFD7EC" stroke-width="6" stroke-linecap="round" opacity=".85">
           <path d="M120 372 q 34 6 60 -6"/>
           <path d="M126 396 q 40 4 70 -10"/>
         </g>
         ${strawFly(150, 330, 1)}
         ${strawFly(300, 300, 0.9)}`
      );
    },

    /* 6 · 狼吹倒木头房 */
    pig6(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(96, 58, 0.7)}
         ${meadow(310)}
         <g transform="rotate(7 212 404)">
           ${house("wood", 218, 404, 1.04)}
         </g>
         ${wolf(80, 400, 0.95, { flip: true })}
         <g stroke="#BFD7EC" stroke-width="6" stroke-linecap="round" opacity=".85">
           <path d="M124 370 q 36 8 62 -4"/>
           <path d="M130 396 q 42 6 72 -8"/>
         </g>
         <g fill="#A9714A" opacity=".9">
           <rect x="290" y="286" width="34" height="10" rx="3" transform="rotate(18 307 291)"/>
           <rect x="250" y="262" width="28" height="9" rx="3" transform="rotate(-14 264 266)"/>
         </g>`
      );
    },

    /* 7 · 砖房吹不动 */
    pig7(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(76, 60, 0.7)}
         ${meadow(312)}
         ${house("brick", 232, 406, 1.1)}
         ${chimney(296, 240, 1.1)}
         ${wolf(74, 404, 1.0, { flip: true })}
         <g stroke="#BFD7EC" stroke-width="6" stroke-linecap="round" opacity=".85">
           <path d="M118 374 q 40 8 68 -2"/>
           <path d="M124 400 q 46 6 78 -8"/>
         </g>
         ${pig(150, 420, 0.6)}
         ${pig(196, 424, 0.6)}`
      );
    },

    /* 8 · 三只小猪的家 */
    pig8(uid) {
      return wrap(
        uid,
        `${skySun(uid)}
         ${cloud(96, 64, 0.9)}
         ${cloud(320, 96, 0.7)}
         ${meadow(300)}
         ${house("brick", 210, 398, 1.12)}
         ${chimney(278, 228, 1.12)}
         ${pig(108, 410, 0.8, { flip: true })}
         ${pig(300, 416, 0.78)}
         <g fill="#F3B0A8">
           <circle cx="60" cy="452" r="5"/>
           <circle cx="66" cy="464" r="4"/>
           <circle cx="340" cy="458" r="5"/>
         </g>`
      );
    },
  });

  /* ---------------- 一本书的内容 ---------------- */

  defineBook({
    id: "three-pigs",
    title: { zh: "三只小猪", en: "The Three Little Pigs" },
    age: "3–6",
    accent: "#E08A7A",
    tag: { zh: "经典童话", en: "Classic tale" },
    author: { zh: "伴读小组", en: "Team Ban Du" },
    cover: "pig8",
    pages: [
      /* 1 */
      {
        scene: "pig1",
        zh: ["猪妈妈有三个孩子。", "他们长大了，要自己盖房子住。"],
        en: ["Mummy Pig had three little pigs.", "They were grown up now, so they had to build houses of their own."],
        fact: {
          zh: { title: "猪的鼻子", body: "猪的鼻子特别灵，能闻到埋在土下面的东西。所以它们总爱用鼻子拱地。" },
          en: { title: "A pig's nose", body: "A pig's nose is very sharp. It can smell things buried under the ground, which is why pigs love to root about in the soil." },
        },
        words: [{ zh: "盖房子", en: "build a house", def: { zh: "搭一座能住的屋子。", en: "To make a house to live in." } }],
        quiz: {
          zh: { prompt: "三只小猪要做什么？", options: [{ icon: "leaf", correct: true, label: "盖房子" }, { icon: "water", label: "去游泳" }, { icon: "moon", label: "睡觉" }] },
          en: { prompt: "What did the three pigs have to do?", options: [{ icon: "leaf", correct: true, label: "Build houses" }, { icon: "water", label: "Go swimming" }, { icon: "moon", label: "Sleep" }] },
        },
        spots: [{ x: 0.33, y: 0.8, zh: "小猪", en: "the little pigs" }],
        sticker: "🐷",
      },
      /* 2 */
      {
        scene: "pig2",
        zh: ["老大用稻草盖房子。", "一会儿就盖好了，他躺下就睡。"],
        en: ["The first pig built his house of straw.", "It took almost no time, and he lay down to sleep."],
        fact: {
          zh: { title: "稻草很轻", body: "稻草又轻又软，一捆一捆扎起来就能盖房。可是一阵大风就能把它吹散。" },
          en: { title: "Straw is light", body: "Straw is light and soft. Bundles of it can make a shelter — but one strong gust can blow it apart." },
        },
        words: [{ zh: "稻草", en: "straw", def: { zh: "晒干的麦秆，又轻又软。", en: "Dried stalks of grain. Light and soft." } }],
        quiz: {
          zh: { prompt: "老大的房子是用什么盖的？", options: [{ icon: "leaf", correct: true, label: "稻草" }, { icon: "stone", label: "砖头" }, { icon: "stone", label: "木头" }] },
          en: { prompt: "What did the first pig build with?", options: [{ icon: "leaf", correct: true, label: "Straw" }, { icon: "stone", label: "Bricks" }, { icon: "stone", label: "Wood" }] },
        },
        spots: [{ x: 0.54, y: 0.66, zh: "稻草房", en: "the straw house" }],
        sticker: "🌾",
      },
      /* 3 */
      {
        scene: "pig3",
        zh: ["老二用木头盖房子。", "木头比稻草结实一些。"],
        en: ["The second pig built his house of wood.", "Wood was a little stronger than straw."],
        fact: {
          zh: { title: "木头要钉牢", body: "木头很结实，但每一块都要钉牢。钉子松了，房子就会摇。" },
          en: { title: "Nail it down", body: "Wood is strong, but every board must be nailed tight. Loose nails make a wobbly house." },
        },
        words: [{ zh: "木头", en: "wood", def: { zh: "从树上锯下来的材料。", en: "Material cut from trees." } }],
        quiz: {
          zh: { prompt: "老二的房子用什么盖？", options: [{ icon: "leaf", correct: true, label: "木头" }, { icon: "stone", label: "砖头" }, { icon: "rain", label: "水" }] },
          en: { prompt: "What did the second pig build with?", options: [{ icon: "leaf", correct: true, label: "Wood" }, { icon: "stone", label: "Bricks" }, { icon: "rain", label: "Water" }] },
        },
        spots: [{ x: 0.52, y: 0.66, zh: "木头房", en: "the wooden house" }],
        sticker: "🪵",
      },
      /* 4 */
      {
        scene: "pig4",
        zh: ["老三用砖头盖房子。", "一块一块，慢慢砌，砌了好多天。"],
        en: ["The third pig built his house of bricks.", "Brick by brick, slowly, for many days."],
        fact: {
          zh: { title: "砖头最结实", body: "砖头又重又硬，一块一块砌起来，中间抹上泥浆，干了以后像石头一样结实。" },
          en: { title: "Bricks are strongest", body: "Bricks are heavy and hard. Stacked with mortar between them, they set as solid as stone." },
        },
        words: [{ zh: "砌", en: "to build (with bricks)", def: { zh: "把砖头一块块叠起来，用泥粘住。", en: "To stack bricks with mortar between them." } }],
        quiz: {
          zh: { prompt: "谁的房子最结实？", options: [{ icon: "stone", correct: true, label: "老三的砖房" }, { icon: "leaf", label: "老大的稻草房" }, { icon: "leaf", label: "老二木头房" }] },
          en: { prompt: "Whose house was strongest?", options: [{ icon: "stone", correct: true, label: "The brick house" }, { icon: "leaf", label: "The straw house" }, { icon: "leaf", label: "The wooden house" }] },
        },
        spots: [{ x: 0.54, y: 0.64, zh: "砖房", en: "the brick house" }],
        sticker: "🧱",
      },
      /* 5 */
      {
        scene: "pig5",
        zh: ["大灰狼来了！", "他深深吸一口气，用力一吹——稻草房飞走了。"],
        en: ["Then the big bad wolf came!", "He took a deep breath and blew — the straw house flew away."],
        fact: {
          zh: { title: "狼的毛很厚", body: "狼身上有两层毛：外面一层挡风挡雨，里面一层又软又暖，所以冬天也不怕冷。" },
          en: { title: "A wolf's coat", body: "A wolf has two layers of fur: a rough outer coat that keeps out wind and rain, and a soft warm layer underneath." },
        },
        words: [{ zh: "吹", en: "to blow", def: { zh: "用嘴用力送出空气。", en: "To push air out hard with your mouth." } }],
        quiz: {
          zh: { prompt: "狼先吹倒了哪个房子？", options: [{ icon: "leaf", correct: true, label: "稻草房" }, { icon: "stone", label: "砖房" }, { icon: "leaf", label: "木头房" }] },
          en: { prompt: "Which house did the wolf blow down first?", options: [{ icon: "leaf", correct: true, label: "The straw house" }, { icon: "stone", label: "The brick house" }, { icon: "leaf", label: "The wooden house" }] },
        },
        spots: [
          { x: 0.2, y: 0.78, zh: "大灰狼", en: "the wolf" },
          { x: 0.6, y: 0.6, zh: "稻草房", en: "the straw house" },
        ],
        sticker: "🐺",
      },
      /* 6 */
      {
        scene: "pig6",
        zh: ["两只小猪跑进木头房。", "狼又吹了一口气，木头房也倒了。"],
        en: ["The two pigs ran into the wooden house.", "The wolf blew again, and down it came."],
        fact: {
          zh: { title: "风的力量", body: "风推着空气跑，跑得越快力量越大。台风能把屋顶掀起来。" },
          en: { title: "The power of wind", body: "Wind is moving air. The faster it moves, the harder it pushes — a storm can lift a roof right off." },
        },
        words: [{ zh: "倒下", en: "fall down", def: { zh: "站不住，塌下来。", en: "To collapse and fall." } }],
        quiz: {
          zh: { prompt: "木头房结实吗？", options: [{ icon: "wind", correct: true, label: "不结实，被吹倒了" }, { icon: "stone", label: "很结实" }] },
          en: { prompt: "Was the wooden house strong enough?", options: [{ icon: "wind", correct: true, label: "No — it blew down" }, { icon: "stone", label: "Yes, very strong" }] },
        },
        spots: [{ x: 0.55, y: 0.62, zh: "木头房", en: "the wooden house" }],
        sticker: "🌬️",
      },
      /* 7 */
      {
        scene: "pig7",
        zh: ["三只小猪躲进砖房。", "狼吹呀吹，房子一动不动。他从烟囱爬进去，正好掉进热水锅。"],
        en: ["All three hid in the brick house.", "The wolf blew and blew, but the house did not move. He climbed down the chimney — and landed in a pot of hot water."],
        fact: {
          zh: { title: "烟囱做什么用", body: "烟囱是把炉子的烟送到屋顶外面的管道。冬天生火时，烟就从这里出去。" },
          en: { title: "What a chimney does", body: "A chimney carries smoke from the fire up through the roof and outside." },
        },
        words: [{ zh: "烟囱", en: "chimney", def: { zh: "屋顶上冒烟的管道。", en: "The pipe on a roof that lets smoke out." } }],
        quiz: {
          zh: { prompt: "狼是从哪里进房子的？", options: [{ icon: "wind", correct: true, label: "烟囱" }, { icon: "stone", label: "门" }, { icon: "water", label: "窗户" }] },
          en: { prompt: "How did the wolf get in?", options: [{ icon: "wind", correct: true, label: "Down the chimney" }, { icon: "stone", label: "Through the door" }, { icon: "water", label: "Through a window" }] },
        },
        spots: [
          { x: 0.71, y: 0.5, zh: "烟囱", en: "the chimney" },
          { x: 0.2, y: 0.8, zh: "大灰狼", en: "the wolf" },
        ],
        sticker: "🏠",
      },
      /* 8 */
      {
        scene: "pig8",
        zh: ["狼烫得跳起来，逃走了。", "三只小猪明白了：慢慢做，才结实。"],
        en: ["The wolf yelped and ran away.", "The three pigs learned something: do it slowly, and it will hold."],
        fact: {
          zh: { title: "砖房能挡风", body: "砖墙又厚又重，风推不动。所以海边的房子常用砖和水泥盖。" },
          en: { title: "Brick walls hold", body: "Brick walls are thick and heavy, so wind cannot push them over. That is why seaside houses are often built of brick and concrete." },
        },
        words: [{ zh: "结实", en: "sturdy", def: { zh: "很牢固，不容易坏。", en: "Strong and hard to break." } }],
        quiz: {
          zh: { prompt: "这个故事告诉我们什么？", options: [{ icon: "stone", correct: true, label: "慢慢做，才结实" }, { icon: "leaf", label: "越快越好" }, { icon: "moon", label: "睡觉最重要" }] },
          en: { prompt: "What does the story teach us?", options: [{ icon: "stone", correct: true, label: "Do it slowly and well" }, { icon: "leaf", label: "Faster is always better" }, { icon: "moon", label: "Sleep matters most" }] },
        },
        spots: [{ x: 0.52, y: 0.62, zh: "砖房", en: "the brick house" }],
        sticker: "⭐",
      },
    ],
  });
})();
