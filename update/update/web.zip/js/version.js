/* 应用版本 —— 由 tools/publish.py 自动维护 */
window.APP_VERSION = {
  name: "2.2.1",
  code: 6,
};
