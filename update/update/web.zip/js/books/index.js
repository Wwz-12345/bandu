/* ============================================================
   书库索引 —— 加一本新书，只改这一个文件：

   1. 在下面的 BOOK_FILES 里加一行文件名（不含 .js）
   2. 在 js/books/ 里新建同名文件，里面调用 defineBook({ ... })
      （复制 snail-moon.js 改内容最快）

   书架会自动多出一本书，不需要改任何别的代码。
   ============================================================ */

var BOOK_FILES = ["snail-moon"];

var BOOKS = [];

function defineBook(book) {
  BOOKS.push(book);
  return book;
}

/* 依次加载每本书的内容文件，全部就绪后把 __booksReady 置为 true */
(function loadBooks() {
  var pending = BOOK_FILES.length;
  if (!pending) {
    window.__booksReady = true;
    return;
  }
  var done = function () {
    pending--;
    if (pending <= 0) window.__booksReady = true;
  };
  for (var i = 0; i < BOOK_FILES.length; i++) {
    var s = document.createElement("script");
    s.src = "js/books/" + BOOK_FILES[i] + ".js";
    s.onload = done;
    s.onerror = done;
    document.head.appendChild(s);
  }
})();
