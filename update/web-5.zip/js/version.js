/* 应用版本 —— 每次发版请同时改这里和 AndroidManifest 的 versionCode/versionName */
window.APP_VERSION = {
  name: "2.1.1",
  code: 4,
  date: "2026-11-09",
};
